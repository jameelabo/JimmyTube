param([string]$ToolCache = 'C:\Users\jamee\.cache\neon-nes-android')
$ErrorActionPreference = 'Stop'
$nesRoot = $PSScriptRoot
$nesBuild = Join-Path $nesRoot 'build'
$nesOut = Join-Path $nesRoot 'dist'
$nesJdk = (Get-ChildItem -LiteralPath (Join-Path $ToolCache 'jdk') -Directory | Select-Object -First 1).FullName
$nesTools = (Get-ChildItem -LiteralPath (Join-Path $ToolCache 'build-tools') -Directory | Select-Object -First 1).FullName
$nesAndroidJar = Join-Path $ToolCache 'platform\android-35\android.jar'
foreach ($nesRequired in @((Join-Path $nesJdk 'bin\javac.exe'),(Join-Path $nesTools 'aapt2.exe'),$nesAndroidJar)) { if (!(Test-Path -LiteralPath $nesRequired)) { throw "Missing build tool: $nesRequired" } }
New-Item -ItemType Directory -Path "$nesBuild\classes","$nesBuild\generated","$nesBuild\dex","$nesBuild\libdex",$nesOut -Force | Out-Null
Get-ChildItem -LiteralPath "$nesBuild\dex","$nesBuild\libdex" -Filter '*.dex' | Remove-Item
function Invoke-NesTool([string]$File,[string[]]$Arguments) { & $File @Arguments; if ($LASTEXITCODE -ne 0) { throw "$File failed ($LASTEXITCODE)" } }

Invoke-NesTool (Join-Path $nesTools 'aapt2.exe') @('compile','--dir',"$nesRoot\app\res",'-o',"$nesBuild\resources.zip")
Invoke-NesTool (Join-Path $nesTools 'aapt2.exe') @('link','-o',"$nesBuild\unsigned.apk",'--manifest',"$nesRoot\app\AndroidManifest.xml",'-I',$nesAndroidJar,'-A',"$nesRoot\app\assets",'--java',"$nesBuild\generated",'--auto-add-overlay',"$nesBuild\resources.zip")
$nesSources = @(Get-ChildItem -Path "$nesRoot\app\java","$nesBuild\generated" -Recurse -Filter '*.java' | ForEach-Object FullName)
Invoke-NesTool (Join-Path $nesJdk 'bin\javac.exe') (@('-encoding','UTF-8','-source','11','-target','11','-classpath',($nesAndroidJar + ';' + "$nesRoot\deps\*" ),'-d',"$nesBuild\classes") + $nesSources)
Invoke-NesTool (Join-Path $nesJdk 'bin\jar.exe') @('cf',"$nesBuild\classes.jar",'-C',"$nesBuild\classes",'.')
Invoke-NesTool (Join-Path $nesJdk 'bin\java.exe') (@('-cp',"$nesTools\lib\d8.jar",'com.android.tools.r8.D8','--release','--min-api','29','--lib',$nesAndroidJar,'--desugared-lib',"$nesRoot\tools\desugar.json",'--desugared-lib-pg-conf-output',"$nesBuild\desugar-keep.pro",'--output',"$nesBuild\dex","$nesBuild\classes.jar") + @(Get-ChildItem -LiteralPath "$nesRoot\deps" -Filter '*.jar' | Where-Object Name -ne 'rhino-engine.jar' | ForEach-Object FullName))
Invoke-NesTool (Join-Path $nesJdk 'bin\java.exe') @('-cp',"$nesTools\lib\d8.jar",'com.android.tools.r8.L8','--release','--min-api','29','--lib',$nesAndroidJar,'--desugared-lib',"$nesRoot\tools\desugar.json",'--pg-conf',"$nesBuild\desugar-keep.pro",'--output',"$nesBuild\libdex","$nesRoot\tools\desugar_jdk_libs.jar","$nesRoot\tools\desugar_config.jar")
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$nesZip = [IO.Compression.ZipFile]::Open("$nesBuild\unsigned.apk",[IO.Compression.ZipArchiveMode]::Update)
try {
    # Windows AAPT2 can emit backslashes in nested asset paths. AssetManager only
    # resolves slash-separated names on Android: normalize entries before signing.
    foreach ($nesEntry in @($nesZip.Entries)) {
        if ($nesEntry.FullName.Contains('\')) {
            $nesFixedName = $nesEntry.FullName.Replace('\','/')
            $nesBuffer = New-Object System.IO.MemoryStream
            $nesInput = $nesEntry.Open()
            try { $nesInput.CopyTo($nesBuffer) } finally { $nesInput.Dispose() }
            $nesEntry.Delete()
            $nesReplacement = $nesZip.CreateEntry($nesFixedName)
            $nesOutput = $nesReplacement.Open()
            try { $nesBuffer.Position = 0; $nesBuffer.CopyTo($nesOutput) } finally { $nesOutput.Dispose(); $nesBuffer.Dispose() }
        }
    }
    foreach ($nesDex in Get-ChildItem -LiteralPath "$nesBuild\dex" -Filter '*.dex') { [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($nesZip,$nesDex.FullName,$nesDex.Name) | Out-Null }
    $tubeDexCount = @(Get-ChildItem -LiteralPath "$nesBuild\dex" -Filter '*.dex').Count
    foreach ($tubeDex in Get-ChildItem -LiteralPath "$nesBuild\libdex" -Filter '*.dex') { $tubeDexCount++; [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($nesZip,$tubeDex.FullName,"classes$tubeDexCount.dex") | Out-Null }
    foreach ($tubeJar in Get-ChildItem -LiteralPath "$nesRoot\deps" -Filter '*.jar' | Where-Object Name -ne 'rhino-engine.jar') {
        $tubeArchive = [IO.Compression.ZipFile]::OpenRead($tubeJar.FullName)
        try { foreach ($tubeEntry in $tubeArchive.Entries) {
            if ($tubeEntry.FullName.EndsWith('/') -or $tubeEntry.FullName.EndsWith('.class') -or $tubeEntry.FullName.StartsWith('META-INF/')) { continue }
            if ($nesZip.GetEntry($tubeEntry.FullName)) { continue }
            $tubeTarget = $nesZip.CreateEntry($tubeEntry.FullName)
            $tubeInput = $tubeEntry.Open(); $tubeOutput = $tubeTarget.Open()
            try { $tubeInput.CopyTo($tubeOutput) } finally { $tubeInput.Dispose(); $tubeOutput.Dispose() }
        } } finally { $tubeArchive.Dispose() }
    }
} finally { $nesZip.Dispose() }
Invoke-NesTool (Join-Path $nesTools 'zipalign.exe') @('-f','-p','4',"$nesBuild\unsigned.apk","$nesBuild\aligned.apk")
$nesKeyFile = Join-Path $ToolCache 'jimmy-tube-signing.jks'
$nesKeyInfo = Join-Path $ToolCache 'jimmy-tube-signing.json'
if (!(Test-Path -LiteralPath $nesKeyFile)) {
    $nesPassword = [guid]::NewGuid().ToString('N')
    Invoke-NesTool (Join-Path $nesJdk 'bin\keytool.exe') @('-genkeypair','-keystore',$nesKeyFile,'-storepass',$nesPassword,'-keypass',$nesPassword,'-alias','jimmy-tube','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=Jimmy Tube, OU=Jimmy Tube, O=Personal, C=IL','-noprompt')
    @{password=$nesPassword} | ConvertTo-Json | Set-Content -LiteralPath $nesKeyInfo -Encoding UTF8
}
$nesPassword = (Get-Content -LiteralPath $nesKeyInfo -Raw | ConvertFrom-Json).password
Invoke-NesTool (Join-Path $nesJdk 'bin\java.exe') @('-jar',"$nesTools\lib\apksigner.jar",'sign','--ks',$nesKeyFile,'--ks-key-alias','jimmy-tube','--ks-pass',"pass:$nesPassword",'--key-pass',"pass:$nesPassword",'--out',"$nesOut\JimmyTube-v2.2.apk","$nesBuild\aligned.apk")
Invoke-NesTool (Join-Path $nesJdk 'bin\java.exe') @('-jar',"$nesTools\lib\apksigner.jar",'verify','--verbose',"$nesOut\JimmyTube-v2.2.apk")
Invoke-NesTool (Join-Path $nesTools 'aapt.exe') @('dump','badging',"$nesOut\JimmyTube-v2.2.apk")
Write-Output "APK ready: $nesOut\JimmyTube-v2.2.apk"








