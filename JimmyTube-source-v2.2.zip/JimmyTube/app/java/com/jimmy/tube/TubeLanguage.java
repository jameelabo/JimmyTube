package com.jimmy.tube;
import android.content.Context;
import android.view.*;
import android.widget.*;
public final class TubeLanguage {
 public static void init(Context c){TubeStrings.english=!"ar".equals(c.getSharedPreferences("tube",0).getString("language","en"));}
 public static void set(Context c,boolean english){c.getSharedPreferences("tube",0).edit().putString("language",english?"en":"ar").apply();TubeStrings.english=english;}
 public static int direction(){return TubeStrings.english?View.LAYOUT_DIRECTION_LTR:View.LAYOUT_DIRECTION_RTL;}
 public static void refresh(View v){if(v instanceof Label)((Label)v).refresh();if(v instanceof Action)((Action)v).refresh();if(v instanceof Spinner){android.widget.Spinner s=(android.widget.Spinner)v;if(s.getAdapter() instanceof BaseAdapter)((BaseAdapter)s.getAdapter()).notifyDataSetChanged();}if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)refresh(g.getChildAt(i));}}
 public static class Label extends TextView {
  private CharSequence original="";private boolean localized=true;
  public Label(Context c){super(c);}
  public void preserveContent(){localized=false;}
  @Override public void setText(CharSequence s,BufferType type){original=s;super.setText(localized?TubeStrings.t(s==null?"":s.toString()):s,type);}
  public void refresh(){super.setText(localized?TubeStrings.t(original==null?"":original.toString()):original,BufferType.NORMAL);}
 }
 public static class Action extends Button {
  private CharSequence original="";
  public Action(Context c){super(c);}
  @Override public void setText(CharSequence s,BufferType type){original=s;super.setText(TubeStrings.t(s==null?"":s.toString()),type);}
  public void refresh(){super.setText(TubeStrings.t(original==null?"":original.toString()),BufferType.NORMAL);}
 }
 public static class Adapter<T> extends ArrayAdapter<T> {
  public Adapter(Context c,int layout,T[] values){super(c,layout,values);}
  public Adapter(Context c,int layout,java.util.List<T> values){super(c,layout,values);}
  private View translate(View v,int pos){if(v instanceof TextView)((TextView)v).setText(TubeStrings.t(String.valueOf(getItem(pos))));return v;}
  @Override public View getView(int pos,View old,ViewGroup parent){return translate(super.getView(pos,old,parent),pos);}
  @Override public View getDropDownView(int pos,View old,ViewGroup parent){return translate(super.getDropDownView(pos,old,parent),pos);}
 }
}
