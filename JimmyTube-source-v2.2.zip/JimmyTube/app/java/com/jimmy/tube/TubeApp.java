package com.jimmy.tube;
import android.app.Application;
public class TubeApp extends Application { @Override public void onCreate(){super.onCreate();TubeLanguage.init(this);TubeEngine.init();} }
