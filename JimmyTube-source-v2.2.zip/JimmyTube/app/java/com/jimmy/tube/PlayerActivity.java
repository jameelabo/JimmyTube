package com.jimmy.tube;
import android.app.*;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import java.io.InputStream;
import android.media.*;
import android.os.*;
import android.view.*;
import android.widget.*;
public class PlayerActivity extends Activity {
 private VideoView video;
 private MediaController controls;
 private int position=0;
 private boolean prepared=false;
 private boolean resumePlayback=true;
 @Override public void onCreate(Bundle b){super.onCreate(b);if(b!=null){position=b.getInt("position");resumePlayback=b.getBoolean("play",true);}
  getWindow().setNavigationBarColor(Color.BLACK);getWindow().setStatusBarColor(Color.BLACK);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.BLACK);root.setPadding(12,12,12,12);root.setLayoutDirection(TubeLanguage.direction());setContentView(root);
  TextView title=new TubeLanguage.Label(this);((TubeLanguage.Label)title).preserveContent();title.setText(getIntent().getStringExtra("title"));title.setTextColor(Color.WHITE);title.setTextSize(18);title.setPadding(16,16,16,16);root.addView(title);
  if(getIntent().getBooleanExtra("audio",false)){
   TextView music=new TubeLanguage.Label(this);music.setText("♫\nصوت بدون إنترنت");music.setTextColor(0xffff6577);music.setTextSize(34);music.setGravity(Gravity.CENTER);root.addView(music);
   ImageView cover=new ImageView(this);cover.setScaleType(ImageView.ScaleType.FIT_CENTER);cover.setVisibility(View.GONE);root.addView(cover,new LinearLayout.LayoutParams(-1,(int)(220*getResources().getDisplayMetrics().density)));
   String mediaUri=getIntent().getData().toString(),legacy=getIntent().getStringExtra("coverUri");
   new Thread(()->{Bitmap bitmap=EmbeddedCover.read(this,mediaUri,legacy);runOnUiThread(()->{if(!isDestroyed()&&bitmap!=null){cover.setImageBitmap(bitmap);cover.setVisibility(View.VISIBLE);music.setVisibility(View.GONE);}});}).start();
  }
  FrameLayout frame=new FrameLayout(this);root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));video=new VideoView(this);frame.addView(video,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));controls=new MediaController(this);controls.setAnchorView(frame);video.setMediaController(controls);
  TextView hint=new TubeLanguage.Label(this);hint.setText("المس الشاشة لإظهار أزرار التشغيل والتقديم");hint.setGravity(Gravity.CENTER);hint.setTextColor(0xffa5aec6);hint.setPadding(12,12,12,12);root.addView(hint);
  Button back=new TubeLanguage.Action(this);back.setText("رجوع إلى المكتبة");root.addView(back);back.setOnClickListener(v->finish());
  video.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build());
  video.setOnPreparedListener(p->{prepared=true;video.seekTo(position);if(resumePlayback)video.start();controls.show();});
  video.setOnErrorListener((p,what,extra)->{new AlertDialog.Builder(this).setTitle(TubeStrings.t("تعذّر تشغيل الملف")).setMessage(TubeStrings.t("قد يكون الملف حُذف أو لا يدعم هاتفك صيغته.")).setPositiveButton(TubeStrings.t("رجوع"),(d,w)->finish()).show();return true;});
  video.setOnCompletionListener(p->{getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);controls.show(0);});
  video.setVideoURI(getIntent().getData());getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
 }
 @Override protected void onPause(){super.onPause();if(prepared){position=video.getCurrentPosition();resumePlayback=video.isPlaying();video.pause();}}
 @Override protected void onResume(){super.onResume();if(prepared&&resumePlayback){video.seekTo(position);video.start();}}
 @Override protected void onSaveInstanceState(Bundle b){b.putInt("position",video.getCurrentPosition());b.putBoolean("play",video.isPlaying());super.onSaveInstanceState(b);}
 @Override protected void onDestroy(){video.stopPlayback();super.onDestroy();}
}
