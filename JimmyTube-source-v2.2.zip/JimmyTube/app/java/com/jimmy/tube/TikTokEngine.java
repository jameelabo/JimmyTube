package com.jimmy.tube;

import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import com.grack.nanojson.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.schabi.newpipe.extractor.Image;

public final class TikTokEngine {
 private static final String DESKTOP_UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
 public static boolean isLink(String text){try{return host(first(text).getHost());}catch(Exception e){return false;}}
 private static boolean host(String h){return h!=null&&Arrays.asList("tiktok.com","www.tiktok.com","m.tiktok.com","vm.tiktok.com","vt.tiktok.com").contains(h.toLowerCase(Locale.ROOT));}
 private static URI first(String text)throws Exception{
  Matcher m=Pattern.compile("https?://[^\\s<>\"\\u200e\\u200f]+").matcher(text==null?"":text);
  if(!m.find())throw new IllegalArgumentException("ألصق رابط فيديو تيك توك كاملًا");return new URI(m.group());
 }
 public static String canonical(String text){
  try{URI u=first(text);String h=u.getHost();if(!host(h)||u.getUserInfo()!=null||(u.getPort()!=-1&&u.getPort()!=443))throw new Exception();
   String path=u.getPath();
   if(path.matches("/@[A-Za-z0-9_.-]+/video/[0-9]{10,25}/?"))return "https://www.tiktok.com"+path.replaceAll("/$","");
   if((h.equalsIgnoreCase("vm.tiktok.com")||h.equalsIgnoreCase("vt.tiktok.com"))&&path.matches("/[A-Za-z0-9_-]{5,100}/?"))return "https://"+h.toLowerCase(Locale.ROOT)+path;
   if((h.equalsIgnoreCase("tiktok.com")||h.equalsIgnoreCase("www.tiktok.com"))&&path.matches("/t/[A-Za-z0-9_-]{5,100}/?"))return "https://www.tiktok.com"+path;
  }catch(Exception ignored){}
  throw new IllegalArgumentException("يدعم تيك توك روابط الفيديو والمشاركة القصيرة فقط؛ الحسابات والبث المباشر ومنشورات الصور غير مدعومة.");
 }
 private static String id(String url){Matcher m=Pattern.compile("/video/([0-9]+)$").matcher(url);return m.find()?m.group(1):null;}
 private static final class Page {String url,html,cookie;Page(String u,String h,String c){url=u;html=h;cookie=c;}}
 private static Page page(String start,String userAgent)throws Exception{
  String url=canonical(start);
  Map<String,String> cookies=new LinkedHashMap<>();
  for(int hop=0;hop<6;hop++){
   HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("User-Agent",userAgent);c.setRequestProperty("Accept-Encoding","identity");c.setRequestProperty("Accept-Language","en-US,en;q=0.9");
   if(!cookies.isEmpty())c.setRequestProperty("Cookie",cookieHeader(cookies));
   try{int code=c.getResponseCode();for(Map.Entry<String,List<String>> header:c.getHeaderFields().entrySet())if("Set-Cookie".equalsIgnoreCase(header.getKey()))for(String line:header.getValue())try{for(HttpCookie cookie:HttpCookie.parse(line))if(cookie.getName().equals("tt_chain_token")||cookie.getName().equals("ttwid"))cookies.put(cookie.getName(),cookie.getValue());}catch(IllegalArgumentException ignored){}
    if(code>=300&&code<400){String next=c.getHeaderField("Location");if(next==null)throw new IOException("Missing TikTok redirect");url=canonical(new URI(url).resolve(next).toString());continue;}
    if(code!=200)throw new IllegalArgumentException("تعذّر فتح فيديو تيك توك (HTTP "+code+"). قد يكون غير متاح أو يحتاج تسجيل دخول.");
    ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("cancelled");bytes.write(b,0,n);if(bytes.size()>8*1024*1024)throw new IOException("TikTok page too large");}}
    if(id(url)==null)throw new IllegalArgumentException("لم يتحول رابط المشاركة إلى فيديو تيك توك؛ جرّب رابط الفيديو الكامل.");
    return new Page(url,new String(bytes.toByteArray(),StandardCharsets.UTF_8),cookieHeader(cookies));
   }finally{c.disconnect();}
  }
  throw new IllegalArgumentException("رابط تيك توك يحتوي تحويلات كثيرة؛ جرّب رابط الفيديو الكامل.");
 }
 private static String cookieHeader(Map<String,String> cookies){List<String> pairs=new ArrayList<>();for(Map.Entry<String,String> c:cookies.entrySet())pairs.add(c.getKey()+"="+c.getValue());return String.join("; ",pairs);}
 public static MediaInfo inspect(String url)throws Exception{
  Exception last=null;
  for(String ua:new String[]{TubeEngine.UA,DESKTOP_UA})try{Page p=page(url,ua);MediaInfo parsed=parse(p.html,p.url);List<TubeEngine.Choice> choices=new ArrayList<>();for(TubeEngine.Choice x:parsed.choices){String source=x.video!=null?x.video:x.audio;String h=new URI(source).getHost();String cookie=h.endsWith(".tiktok.com")?p.cookie:null;choices.add(new TubeEngine.Choice(x.label,x.video,x.audio,x.extension,x.mime,x.referer,cookie));}return new MediaInfo(parsed.getUrl(),parsed.getName(),parsed.getUploaderName(),parsed.getDuration(),parsed.getThumbnails(),choices);}catch(InterruptedIOException e){throw e;}catch(Exception e){last=e;}
  throw last;
 }
 private static JsonObject object(JsonObject o,String key){return o==null?null:o.getObject(key);}
 private static JsonObject find(Object data,String wanted,int depth){
  if(depth>16)return null;
  if(data instanceof JsonObject){JsonObject o=(JsonObject)data;
   if(wanted.equals(String.valueOf(o.get("id")))&&o.getObject("video")!=null)return o;
   for(Object value:o.values()){JsonObject result=find(value,wanted,depth+1);if(result!=null)return result;}
  }else if(data instanceof JsonArray)for(Object value:(JsonArray)data){JsonObject result=find(value,wanted,depth+1);if(result!=null)return result;}
  return null;
 }
 private static String mediaUrl(Object value){
  if(value instanceof String){String s=(String)value;if(s.startsWith("//"))s="https:"+s;try{URI u=new URI(s);if("https".equals(u.getScheme())&&u.getHost()!=null&&u.getUserInfo()==null&&(u.getPort()==-1||u.getPort()==443)){String h=u.getHost().toLowerCase(Locale.ROOT);if(h.endsWith(".tiktok.com")||h.endsWith(".tiktokcdn.com")||h.endsWith(".tiktokcdn-us.com")||h.endsWith(".tiktokv.com")||h.endsWith(".muscdn.com")||h.endsWith(".byteoversea.com")||h.endsWith(".ibytedtos.com"))return s;}}catch(Exception ignored){}return null;}
  if(value instanceof JsonArray)for(Object x:(JsonArray)value){String s=mediaUrl(x);if(s!=null)return s;}
  if(value instanceof JsonObject)for(String key:new String[]{"src","url","UrlList","urlList"}){String s=mediaUrl(((JsonObject)value).get(key));if(s!=null)return s;}
  return null;
 }
 public static MediaInfo parse(String html,String url)throws Exception{
  url=canonical(url);String wanted=id(url);if(wanted==null)throw new IllegalArgumentException("رابط فيديو تيك توك كامل مطلوب");
  JsonObject item=null;
  for(String scriptId:new String[]{"api-data","__UNIVERSAL_DATA_FOR_REHYDRATION__","SIGI_STATE","__NEXT_DATA__"}){
   Element script=Jsoup.parse(html).getElementById(scriptId);if(script==null)continue;
   try{JsonObject root=JsonParser.object().from(script.data());
    JsonObject detail=scriptId.equals("api-data")?root.getObject("videoDetail"):object(root.getObject("__DEFAULT_SCOPE__"),"webapp.video-detail");
    if(detail!=null&&detail.getInt("statusCode",0)!=0)throw new IllegalArgumentException("فيديو تيك توك غير متاح أو يحتاج تسجيل دخول.");
    item=find(root,wanted,0);if(item!=null)break;
   }catch(JsonParserException ignored){}
  }
  if(item==null)throw new IllegalArgumentException("تيك توك لم يوفّر بيانات الفيديو. قد يطلب تحققًا أو تسجيل دخول؛ جرّب رابطًا آخر أو حاول لاحقًا.");
  JsonObject video=item.getObject("video");if(item.get("imagePost")!=null||video.getInt("duration",0)<=0)throw new IllegalArgumentException("منشورات الصور في تيك توك غير مدعومة حاليًا.");
  // Use complete video audio; music.playUrl may omit narration and effects.
  String source=mediaUrl(video.get("downloadAddr"));if(source==null)source=mediaUrl(video.get("playAddr"));
  if(source==null||source.contains("/media-video-hvc1/"))throw new IllegalArgumentException("لم يتوفر ملف فيديو كامل مدعوم من تيك توك.");
  String title=item.getString("desc","").trim();if(title.isEmpty())title="TikTok "+wanted;if(title.length()>160)title=title.substring(0,title.offsetByCodePoints(0,Math.min(120,title.codePointCount(0,title.length()))));
  JsonObject author=item.getObject("author");String uploader=author==null?"TikTok":author.getString("nickname",author.getString("uniqueId","TikTok"));
  List<Image> images=new ArrayList<>();for(String key:new String[]{"originCover","cover"}){String cover=mediaUrl(video.get(key));if(cover!=null)images.add(new Image(cover,video.getInt("height",-1),video.getInt("width",-1),Image.ResolutionLevel.UNKNOWN));}
  List<TubeEngine.Choice> choices=new ArrayList<>();choices.add(new TubeEngine.Choice("فيديو MP4 · تيك توك",source,null,"mp4","video/mp4",url));choices.add(new TubeEngine.Choice("صوت فقط MP3 · 192 kbps",null,source,"mp3","audio/mpeg",url));
  return new MediaInfo(url,title,uploader,video.getInt("duration",0),images,choices);
 }
}
