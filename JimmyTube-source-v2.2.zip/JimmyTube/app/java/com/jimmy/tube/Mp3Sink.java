package com.jimmy.tube;

import io.vacco.libmp3lame.Jlame;
import io.vacco.libmp3lame.Jlame_global_flags;
import java.io.*;
import java.nio.*;

/** Streaming PCM-to-MP3; no native libraries or desktop audio APIs. */
public final class Mp3Sink implements Closeable {
 private final Jlame_global_flags flags;
 private final OutputStream out;
 private final int channels;
 private final short[] pcm=new short[8192];
 private final byte[] encoded=new byte[16384];
 private boolean finished=false,closed=false;
 private long frames=0;
 public Mp3Sink(OutputStream output,int sampleRate,int channels)throws IOException {
  if(channels!=1&&channels!=2)throw new IOException("MP3 requires mono or stereo audio");
  this.channels=channels;out=output;flags=Jlame.lame_init();if(flags==null)throw new IOException("Cannot initialize MP3 encoder");
  flags.lame_set_num_channels(channels);flags.lame_set_out_samplerate(sampleRate);
  flags.lame_set_brate(sampleRate>=32000?192:128);flags.lame_set_quality(5);
  flags.lame_set_mode(channels==1?Jlame.MONO:Jlame.JOINT_STEREO);
  flags.lame_set_VBR(Jlame.vbr_off);flags.lame_set_bWriteVbrTag(false);flags.lame_set_write_id3tag_automatic(false);
  int result=Jlame.lame_init_params(flags);if(result<0){Jlame.lame_close(flags);throw new IOException("MP3 initialization failed: "+result);}
 }
 public long frames(){return frames;}
 public void write(ByteBuffer buffer,boolean floatPcm)throws IOException {
  if(finished||closed)throw new IOException("MP3 encoder already finished");
  buffer.order(ByteOrder.LITTLE_ENDIAN);int width=floatPcm?4:2;
  if(buffer.remaining()%(width*channels)!=0)throw new IOException("Unaligned PCM audio");
  while(buffer.remaining()>0){int samples=Math.min(pcm.length,buffer.remaining()/width);samples-=samples%channels;
   for(int n=0;n<samples;n++)if(floatPcm){float value=buffer.getFloat();pcm[n]=(short)Math.round(Math.max(-1f,Math.min(1f,value))*32767f);}else pcm[n]=buffer.getShort();
   int count=samples/channels;
   int bytes=channels==2?Jlame.lame_encode_buffer_interleaved(flags,pcm,count,encoded,0,encoded.length):Jlame.lame_encode_buffer(flags,pcm,pcm,count,encoded,0,encoded.length);
   if(bytes<0)throw new IOException("MP3 encoding failed: "+bytes);out.write(encoded,0,bytes);frames+=count;
  }
 }
 public void finish()throws IOException {if(finished)return;int bytes=Jlame.lame_encode_flush(flags,encoded,encoded.length);if(bytes<0)throw new IOException("MP3 flush failed: "+bytes);out.write(encoded,0,bytes);out.flush();finished=true;}
 @Override public void close(){if(!closed){closed=true;Jlame.lame_close(flags);}}
}
