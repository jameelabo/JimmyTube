package com.jimmy.tube;

import android.media.*;
import java.io.*;
import java.nio.*;

public final class Mp3Converter {
 public interface Monitor {void check()throws InterruptedIOException;void progress(int percent);}
 public static void convert(File input,File output,Monitor monitor)throws Exception {
  MediaExtractor extractor=new MediaExtractor();MediaCodec decoder=null;Mp3Sink sink=null;boolean started=false;
  try(OutputStream out=new BufferedOutputStream(new FileOutputStream(output))){
   extractor.setDataSource(input.getAbsolutePath());int track=-1;
   for(int n=0;n<extractor.getTrackCount();n++){String mime=extractor.getTrackFormat(n).getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("audio/")){track=n;break;}}
   if(track<0)throw new IOException("Audio track missing");extractor.selectTrack(track);
   MediaFormat format=extractor.getTrackFormat(track);long duration=format.containsKey(MediaFormat.KEY_DURATION)?format.getLong(MediaFormat.KEY_DURATION):0;
   format.setInteger(MediaFormat.KEY_PCM_ENCODING,AudioFormat.ENCODING_PCM_16BIT);
   decoder=MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME));decoder.configure(format,null,null,0);decoder.start();started=true;
   boolean inputDone=false,outputDone=false,floatPcm=false;int rate=0;MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();long lastOutput=System.nanoTime();
   while(!outputDone){monitor.check();
    if(!inputDone){int index=decoder.dequeueInputBuffer(10000);if(index>=0){ByteBuffer data=decoder.getInputBuffer(index);if(data==null)throw new IOException("Decoder input missing");data.clear();int size=extractor.readSampleData(data,0);if(size<0){decoder.queueInputBuffer(index,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}else{decoder.queueInputBuffer(index,0,size,extractor.getSampleTime(),0);extractor.advance();}}}
    int index=decoder.dequeueOutputBuffer(info,10000);
    if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){MediaFormat actual=decoder.getOutputFormat();rate=actual.getInteger(MediaFormat.KEY_SAMPLE_RATE);int channels=actual.getInteger(MediaFormat.KEY_CHANNEL_COUNT);int encoding=actual.containsKey(MediaFormat.KEY_PCM_ENCODING)?actual.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;
     if(encoding!=AudioFormat.ENCODING_PCM_16BIT&&encoding!=AudioFormat.ENCODING_PCM_FLOAT)throw new IOException("Unsupported decoded PCM format");floatPcm=encoding==AudioFormat.ENCODING_PCM_FLOAT;
     if(sink!=null)throw new IOException("Audio format changed during conversion");sink=new Mp3Sink(out,rate,channels);lastOutput=System.nanoTime();
    }else if(index>=0){try{
     if(info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0){if(sink==null)throw new IOException("Decoder format missing");ByteBuffer data=decoder.getOutputBuffer(index);if(data==null)throw new IOException("Decoder output missing");data.position(info.offset);data.limit(info.offset+info.size);sink.write(data,floatPcm);monitor.check();long timestamp=sink.frames()*1000000L/rate;monitor.progress(duration>0?(int)Math.min(99,timestamp*100/duration):0);}
     outputDone=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;lastOutput=System.nanoTime();
    }finally{decoder.releaseOutputBuffer(index,false);}}
    else if(System.nanoTime()-lastOutput>60000000000L)throw new IOException("Audio decoder timed out");
   }
   monitor.check();if(sink==null||sink.frames()==0)throw new IOException("No decoded audio");sink.finish();monitor.progress(100);
  }finally{if(sink!=null)sink.close();if(decoder!=null){if(started)try{decoder.stop();}catch(Exception ignored){}decoder.release();}extractor.release();}
  if(output.length()==0)throw new IOException("Empty MP3 file");
 }
}
