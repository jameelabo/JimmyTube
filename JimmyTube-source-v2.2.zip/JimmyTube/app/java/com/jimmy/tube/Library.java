package com.jimmy.tube;
import android.content.Context;
import org.json.*;
public final class Library {
 public static synchronized JSONArray read(Context c){try{return new JSONArray(c.getSharedPreferences("tube",0).getString("library","[]"));}catch(Exception e){return new JSONArray();}}
 public static synchronized void add(Context c,JSONObject item){JSONArray old=read(c),now=new JSONArray();now.put(item);for(int i=0;i<old.length();i++)now.put(old.optJSONObject(i));write(c,now);}
 public static synchronized void remove(Context c,String uri){JSONArray old=read(c),now=new JSONArray();for(int i=0;i<old.length();i++){JSONObject x=old.optJSONObject(i);if(x!=null&&!uri.equals(x.optString("uri")))now.put(x);}write(c,now);}
 private static void write(Context c,JSONArray a){c.getSharedPreferences("tube",0).edit().putString("library",a.toString()).commit();}
 public static String friendly(Throwable e){String type=e.getClass().getSimpleName();String msg=e.getMessage()==null?"":e.getMessage();if(type.contains("ReCaptcha")||msg.contains("429"))return "الموقع قيّد الاتصال مؤقتًا. جرّب لاحقًا أو على شبكة أخرى.";if(type.contains("AgeRestricted")||msg.toLowerCase().contains("sign in")||msg.toLowerCase().contains("age-restricted"))return "هذا الفيديو يحتاج تسجيل دخول أو تأكيد العمر؛ غير مدعوم في هذه النسخة.";if(type.contains("Unavailable")||type.contains("NotAvailable"))return "الفيديو غير متاح؛ قد يكون خاصًا أو محذوفًا أو مقيّدًا في بلدك.";if(e instanceof java.net.UnknownHostException||e instanceof java.net.SocketTimeoutException)return "تعذّر الاتصال. تحقّق من الإنترنت وأعد المحاولة.";if(msg.contains("403"))return "رفض الموقع رابط التنزيل. أعد فحص الفيديو أو حاول لاحقًا.";if(e instanceof IllegalArgumentException)return msg;return "تعذّر إكمال العملية. جرّب مرة أخرى. التفاصيل: "+type+(msg.isEmpty()?"":" — "+msg.substring(0,Math.min(220,msg.length())));}
}

