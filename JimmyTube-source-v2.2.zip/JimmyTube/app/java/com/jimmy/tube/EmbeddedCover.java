package com.jimmy.tube;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import java.io.InputStream;

public final class EmbeddedCover {
 public static Bitmap read(Context context,String mediaUri,String legacyCoverUri){
  BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=2;
  if(legacyCoverUri!=null&&!legacyCoverUri.isEmpty()){
   try(InputStream in=context.getContentResolver().openInputStream(Uri.parse(legacyCoverUri))){
    Bitmap bitmap=BitmapFactory.decodeStream(in,null,options);if(bitmap!=null)return bitmap;
   }catch(Exception ignored){}
  }
  MediaMetadataRetriever reader=new MediaMetadataRetriever();
  try{
   reader.setDataSource(context,Uri.parse(mediaUri));byte[] data=reader.getEmbeddedPicture();
   return data==null?null:BitmapFactory.decodeByteArray(data,0,data.length,options);
  }catch(Exception ignored){return null;}
  finally{try{reader.release();}catch(Exception ignored){}}
 }
}
