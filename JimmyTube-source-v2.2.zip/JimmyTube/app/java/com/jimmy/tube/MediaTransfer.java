package com.jimmy.tube;
import java.io.*;
import java.net.*;

/** Range downloading shared by Android and the desktop integration probe. */
public final class MediaTransfer {
 public interface Monitor {
  void check() throws InterruptedIOException;
  void connection(HttpURLConnection connection);
  void progress(long done,long total);
 }
 public static void download(String url,File file,Monitor monitor)throws Exception {
  download(url,file,monitor,null);
 }
 public static void download(String url,File file,Monitor monitor,String referer)throws Exception {
  download(url,file,monitor,referer,null);
 }
 public static void download(String url,File file,Monitor monitor,String referer,String cookie)throws Exception {
  long offset=0,total=-1;final long chunk=2*1024*1024;
  try(OutputStream out=new BufferedOutputStream(new FileOutputStream(file))){
   while(total<0||offset<total){monitor.check();
    HttpURLConnection c=connect(url,offset,chunk,monitor,referer,cookie);
    try{
     int code=c.getResponseCode();if(code!=200&&code!=206)throw new IOException("HTTP "+code);
     String type=c.getContentType();if(type!=null&&(type.contains("text/")||type.contains("json")))throw new IOException("Server did not send media");
     String range=c.getHeaderField("Content-Range");
     if(code==206){if(range==null||!range.startsWith("bytes "+offset+"-"))throw new IOException("Invalid byte range");int slash=range.lastIndexOf('/');if(slash>0&&!range.substring(slash+1).equals("*"))total=Long.parseLong(range.substring(slash+1));}
     else{if(offset!=0)throw new IOException("Server does not support continuation");total=c.getContentLengthLong();}
     if(total>0&&total-offset>file.getParentFile().getUsableSpace()-16*1024*1024)throw new IllegalArgumentException("المساحة المتاحة لا تكفي لتنزيل هذا الملف.");
     long before=offset;
     try(InputStream in=c.getInputStream()){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){monitor.check();out.write(b,0,n);offset+=n;monitor.progress(offset,total);}}
     if(offset==before)throw new IOException("Empty media response");
     if(code==200){if(total>0&&offset!=total)throw new IOException("Incomplete media response");break;}
     if(total<0)throw new IOException("Unknown media length");
    }finally{monitor.connection(null);c.disconnect();}
   }
  }
  if(file.length()==0)throw new IOException("Empty download");
 }
 private static HttpURLConnection connect(String url,long offset,long chunk,Monitor monitor,String referer,String cookie)throws Exception{
  for(int hop=0;hop<6;hop++){
   monitor.check();URL target=new URL(url);HttpURLConnection c=(HttpURLConnection)target.openConnection();monitor.connection(c);boolean returned=false;
   try{
    c.setInstanceFollowRedirects(cookie==null);c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setRequestProperty("User-Agent",TubeEngine.UA);c.setRequestProperty("Range","bytes="+offset+"-"+(offset+chunk-1));c.setRequestProperty("Accept-Encoding","identity");
    if(referer!=null)c.setRequestProperty("Referer",referer);
    if(cookie!=null&&target.getProtocol().equals("https")&&target.getHost().toLowerCase(java.util.Locale.ROOT).endsWith(".tiktok.com"))c.setRequestProperty("Cookie",cookie);
    int code=c.getResponseCode();
    if(cookie!=null&&code>=300&&code<400){String next=c.getHeaderField("Location");if(next==null)throw new IOException("Missing media redirect");url=target.toURI().resolve(next).toString();if(!url.startsWith("https://"))throw new IOException("Unsafe media redirect");continue;}
    returned=true;return c;
   }finally{if(!returned){monitor.connection(null);c.disconnect();}}
  }
  throw new IOException("Too many media redirects");
 }
}
