package com.jimmy.tube;

import java.util.*;
import org.schabi.newpipe.extractor.Image;
import org.schabi.newpipe.extractor.stream.StreamInfo;

/** Metadata shared by the supported sources without changing YouTube policy. */
public final class MediaInfo {
 private final String url,name,author;
 private final long duration;
 private final List<Image> images;
 public final List<TubeEngine.Choice> choices;
 public MediaInfo(String u,String n,String a,long d,List<Image> i,List<TubeEngine.Choice> c){url=u;name=n;author=a;duration=d;images=i;choices=c;}
 public static MediaInfo youtube(StreamInfo info){return new MediaInfo(info.getUrl(),info.getName(),info.getUploaderName(),info.getDuration(),info.getThumbnails(),TubeEngine.choices(info));}
 public String getUrl(){return url;}
 public String getName(){return name;}
 public String getUploaderName(){return author;}
 public long getDuration(){return duration;}
 public List<Image> getThumbnails(){return images;}
}
