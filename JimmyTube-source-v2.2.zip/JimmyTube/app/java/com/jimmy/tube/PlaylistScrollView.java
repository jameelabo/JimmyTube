package com.jimmy.tube;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewParent;
import android.widget.ScrollView;

/** Keeps gestures starting in the playlist away from the outer page. */
public final class PlaylistScrollView extends ScrollView {
 public PlaylistScrollView(Context context){
  super(context);
  setNestedScrollingEnabled(false);
 }
 @Override public boolean dispatchTouchEvent(MotionEvent event){
  ViewParent parent=getParent();
  if(parent!=null)parent.requestDisallowInterceptTouchEvent(true);
  try{return super.dispatchTouchEvent(event);}
  finally{
   int action=event.getActionMasked();
   if(parent!=null&&(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL))
    parent.requestDisallowInterceptTouchEvent(false);
  }
 }
}
