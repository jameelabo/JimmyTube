package com.jimmy.tube;

import java.net.*;
import java.util.*;
import java.util.regex.*;
import org.schabi.newpipe.extractor.stream.*;

public final class PlaylistSupport {
 public static final int LIMIT=500;
 public static String folderName(String title){
  String name=title==null?"":title.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_").trim();
  name=name.replaceAll("^\\.+|[. ]+$","");
  // Keep one filesystem component, bounded in UTF-8 without splitting emoji.
  while(name.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>180)
   name=name.substring(0,name.offsetByCodePoints(name.length(),-1));
  name=name.replaceAll("[. ]+$","");
  return name.isEmpty()?"Playlist":name;
 }
 // Returns null for a regular video; never accepts a playlist on another host.
 public static String canonical(String text){
  if(text==null)return null;
  Matcher m=Pattern.compile("https?://[^\\s<>\"\\u200e\\u200f]+").matcher(text);
  if(!m.find())return null;
  try{URI u=new URI(m.group());String h=u.getHost();if(h==null)return null;h=h.toLowerCase(Locale.ROOT);
   if(!(h.equals("youtu.be")||h.equals("youtube.com")||h.endsWith(".youtube.com")))return null;
   if(u.getRawQuery()==null)return null;
   for(String p:u.getRawQuery().split("&"))if(p.startsWith("list=")){
    String id=URLDecoder.decode(p.substring(5),"UTF-8");
    if(id.equals("WL")||id.equals("LL"))throw new IllegalArgumentException("هذه القائمة تحتاج تسجيل دخول؛ استخدم قائمة عامة أو غير مدرجة.");
    if(!id.matches("[A-Za-z0-9_-]{10,200}"))throw new IllegalArgumentException("رابط قائمة التشغيل غير صحيح.");
    if(id.startsWith("RD"))throw new IllegalArgumentException("قوائم Mix التلقائية غير مدعومة؛ استخدم قائمة تشغيل ثابتة.");
    return "https://www.youtube.com/playlist?list="+id;
   }
   return null;
  }catch(IllegalArgumentException e){throw e;}catch(Exception e){return null;}
 }
 public static TubeEngine.Choice choose(List<TubeEngine.Choice> options,String mode,int height){
  TubeEngine.Choice best=null,lowest=null;int bestHeight=-1,lowHeight=Integer.MAX_VALUE;
  for(TubeEngine.Choice c:options){
   if(mode.equals("mp3")){if(c.extension.equals("mp3"))return c;continue;}
   if(!c.extension.equals("mp4"))continue;
   Matcher m=Pattern.compile("(\\d+)p").matcher(c.label);if(!m.find())continue;int h=Integer.parseInt(m.group(1));
   if(h<lowHeight){lowHeight=h;lowest=c;}if(h<=height&&h>bestHeight){bestHeight=h;best=c;}
  }
  return best!=null?best:lowest;
 }
 public static final class Item {
  public final String url,title;
  public boolean selected=true;
  public Item(String u,String t){url=u;title=t;}
 }
 public static int append(List<Item> target,List<StreamInfoItem> incoming){
  Set<String> seen=new HashSet<>();for(Item x:target)seen.add(x.url);int skipped=0;
  for(StreamInfoItem x:incoming){
   if(target.size()>=LIMIT)break;
   if(x.getStreamType()!=StreamType.VIDEO_STREAM&&x.getStreamType()!=StreamType.POST_LIVE_STREAM){skipped++;continue;}
   try{String url=TubeEngine.canonical(x.getUrl());if(seen.add(url))target.add(new Item(url,x.getName()));else skipped++;}catch(Exception e){skipped++;}
  }
  return skipped;
 }
}
