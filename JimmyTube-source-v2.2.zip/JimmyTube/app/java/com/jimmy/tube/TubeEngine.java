package com.jimmy.tube;

import org.schabi.newpipe.extractor.*;
import org.schabi.newpipe.extractor.downloader.*;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;
import org.schabi.newpipe.extractor.stream.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public final class TubeEngine {
    public static final String UA="Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36";
    public static synchronized void init() { NewPipe.init(new Network()); }
    public static String sourceUrl(String text){return TikTokEngine.isLink(text)?TikTokEngine.canonical(text):canonical(text);}
    public static MediaInfo inspect(String url)throws Exception{return TikTokEngine.isLink(url)?TikTokEngine.inspect(url):MediaInfo.youtube(StreamInfo.getInfo(canonical(url)));}
    public static String canonical(String text) {
        if(text==null) throw new IllegalArgumentException("ألصق رابط فيديو من يوتيوب");
        Matcher match=Pattern.compile("https?://[^\\s<>\"\\u200e\\u200f]+").matcher(text);
        if(!match.find()) throw new IllegalArgumentException("الرابط غير صحيح — استخدم رابط يوتيوب كاملًا");
        try {
            URI u=new URI(match.group()); String host=u.getHost();
            if(host==null) throw new Exception(); host=host.toLowerCase(Locale.ROOT);
            String id=null; String path=u.getPath();
            if(host.equals("youtu.be")) id=path.substring(1).split("/")[0];
            else if(host.equals("youtube.com")||host.endsWith(".youtube.com")||host.equals("youtube-nocookie.com")||host.endsWith(".youtube-nocookie.com")) {
                if(path.startsWith("/shorts/")||path.startsWith("/embed/")||path.startsWith("/live/")) id=path.split("/")[2];
                else if(path.equals("/watch") && u.getRawQuery()!=null) for(String p:u.getRawQuery().split("&")) if(p.startsWith("v=")) id=URLDecoder.decode(p.substring(2),"UTF-8");
            }
            if(id==null||!id.matches("[A-Za-z0-9_-]{11}")) throw new Exception();
            return "https://www.youtube.com/watch?v="+id;
        } catch(Exception e){throw new IllegalArgumentException("يدعم التطبيق روابط فيديوهات يوتيوب وShorts فقط");}
    }
    public static final class Choice {
        public final String label, video, audio, extension, mime, referer, cookie;
        public Choice(String l,String v,String a,String e,String m){this(l,v,a,e,m,null);}
        public Choice(String l,String v,String a,String e,String m,String r){this(l,v,a,e,m,r,null);}
        public Choice(String l,String v,String a,String e,String m,String r,String c){label=l;video=v;audio=a;extension=e;mime=m;referer=r;cookie=c;}
        public boolean needsMux(){return video!=null&&audio!=null;}
        public String toString(){return label;}
    }
    public static List<Choice> choices(StreamInfo info) {
        ArrayList<Choice> out=new ArrayList<>();
        AudioStream best=originalAudio(info.getAudioStreams());
        boolean separate=hasTrackMetadata(info.getAudioStreams());
        TreeMap<Integer,Choice> videos=new TreeMap<>(Collections.reverseOrder());
        // Combined streams may carry YouTube's localized default dub. With track
        // metadata, use a silent video stream plus the selected original audio.
        if(!separate) for(VideoStream s:info.getVideoStreams()) if(s.isUrl()&&s.getDeliveryMethod()==DeliveryMethod.PROGRESSIVE_HTTP&&s.getFormat()==MediaFormat.MPEG_4) videos.put(s.getHeight(),new Choice("فيديو MP4 · "+s.getResolution(),s.getContent(),null,"mp4","video/mp4"));
        if(best!=null) for(VideoStream s:info.getVideoOnlyStreams()) if(s.isUrl()&&s.getDeliveryMethod()==DeliveryMethod.PROGRESSIVE_HTTP&&s.getFormat()==MediaFormat.MPEG_4 && s.getHeight()<=2160 && s.getCodec()!=null && s.getCodec().startsWith("avc") && !videos.containsKey(s.getHeight())) videos.put(s.getHeight(),new Choice("فيديو MP4 · "+s.getResolution(),s.getContent(),best.getContent(),"mp4","video/mp4"));
        out.addAll(videos.values());
        if(best!=null) out.add(new Choice("صوت فقط MP3 · 192 kbps",null,best.getContent(),"mp3","audio/mpeg"));
        return out;
    }
    private static String trackKey(AudioStream stream){String id=stream.getAudioTrackId();if(id!=null&&!id.isEmpty())return id;Locale locale=stream.getAudioLocale();return locale==null?"legacy":locale.toLanguageTag();}
    public static boolean hasTrackMetadata(List<AudioStream> streams){Set<String> keys=new HashSet<>();for(AudioStream s:streams){if(s.getAudioTrackType()!=null)return true;keys.add(trackKey(s));}return keys.size()>1;}
    public static AudioStream originalAudio(List<AudioStream> streams){
        Set<String> originalKeys=new HashSet<>();boolean markedOriginal=false;
        for(AudioStream s:streams)if(s.getAudioTrackType()==AudioTrackType.ORIGINAL){markedOriginal=true;originalKeys.add(trackKey(s));}
        AudioStream best=null;Set<String> unknownKeys=new HashSet<>();
        for(AudioStream s:streams){
            if(!s.isUrl()||s.getDeliveryMethod()!=DeliveryMethod.PROGRESSIVE_HTTP||s.getFormat()!=MediaFormat.M4A)continue;
            AudioTrackType type=s.getAudioTrackType();
            if(type!=null&&type!=AudioTrackType.ORIGINAL)continue;
            if(markedOriginal&&type!=AudioTrackType.ORIGINAL&&!originalKeys.contains(trackKey(s)))continue;
            if(!markedOriginal)unknownKeys.add(trackKey(s));
            int priority=type==AudioTrackType.ORIGINAL?1:0;
            int bestPriority=best!=null&&best.getAudioTrackType()==AudioTrackType.ORIGINAL?1:0;
            if(best==null||priority>bestPriority||(priority==bestPriority&&s.getAverageBitrate()>best.getAverageBitrate()))best=s;
        }
        // Unlabelled legacy single-track videos remain supported. Ambiguous
        // multi-track results never silently pick an arbitrary language.
        if(!markedOriginal&&unknownKeys.size()>1)return null;
        return best;
    }
    public static final class Network extends Downloader {
        @Override public Response execute(Request request) throws IOException,ReCaptchaException {
            HttpURLConnection c=(HttpURLConnection)new URL(request.url()).openConnection();
            c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setRequestMethod(request.httpMethod());
            c.setRequestProperty("User-Agent",UA);c.setRequestProperty("Accept-Encoding","identity");
            for(Map.Entry<String,List<String>> h:request.headers().entrySet()) {
                if(h.getKey().equalsIgnoreCase("Accept-Encoding"))continue;
                c.setRequestProperty(h.getKey(),String.join(", ",h.getValue()));
            }
            try {
                byte[] data=request.dataToSend(); if(data!=null){c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(data);}}
                int code=c.getResponseCode();
                if(code==429)throw new ReCaptchaException("YouTube rate limited this connection",request.url());
                InputStream source=code>=400?c.getErrorStream():c.getInputStream();
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                if(source!=null)try(InputStream in=source){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1){bytes.write(b,0,n);if(bytes.size()>32*1024*1024)throw new IOException("Response too large");}}
                return new Response(code,c.getResponseMessage(),c.getHeaderFields(),new String(bytes.toByteArray(),StandardCharsets.UTF_8),c.getURL().toString());
            }finally{c.disconnect();}
        }
    }
}
