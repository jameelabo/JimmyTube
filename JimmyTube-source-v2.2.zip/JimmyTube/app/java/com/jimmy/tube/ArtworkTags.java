package com.jimmy.tube;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Embed JPEG artwork without re-encoding any media samples. */
public final class ArtworkTags {
 public interface Monitor {void check()throws InterruptedIOException;}
 private static final int MAX_METADATA=32*1024*1024;
 private static byte[] atom(String type,byte[] payload)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream d=new DataOutputStream(b);d.writeInt(payload.length+8);d.write(type.getBytes(StandardCharsets.ISO_8859_1));d.write(payload);return b.toByteArray();}
 private static byte[] join(byte[]... parts)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();for(byte[] p:parts)b.write(p);return b.toByteArray();}
 private static byte[] utf8(String s){return (s==null?"":s).getBytes(StandardCharsets.UTF_8);}
 private static byte[] data(int type,byte[] value)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream d=new DataOutputStream(b);d.writeInt(type);d.writeInt(0);d.write(value);return atom("data",b.toByteArray());}
 private static byte[] metadata(byte[] jpeg,String title,String artist)throws IOException{
  ByteArrayOutputStream handler=new ByteArrayOutputStream();DataOutputStream h=new DataOutputStream(handler);h.writeInt(0);h.writeInt(0);h.writeBytes("mdir");h.write(new byte[12]);h.writeBytes("appl");h.writeByte(0);
  byte[] ilst=atom("ilst",join(atom("covr",data(13,jpeg)),atom("\u00a9nam",data(1,utf8(title))),atom("\u00a9ART",data(1,utf8(artist)))));
  return atom("meta",join(new byte[4],atom("hdlr",handler.toByteArray()),ilst));
 }
 private static void frame(DataOutputStream out,String id,byte[] bytes)throws IOException{out.writeBytes(id);out.writeInt(bytes.length);out.writeShort(0);out.write(bytes);}
 private static byte[] textFrame(String value)throws IOException{return join(new byte[]{1},(value==null?"":value).getBytes("UTF-16"));}
 public static void mp3(File input,File output,byte[] jpeg,String title,String artist,Monitor monitor)throws IOException{
  if(jpeg.length==0||jpeg.length>8*1024*1024)throw new IOException("Invalid cover size");
  ByteArrayOutputStream payload=new ByteArrayOutputStream();DataOutputStream frames=new DataOutputStream(payload);frame(frames,"TIT2",textFrame(title));frame(frames,"TPE1",textFrame(artist));
  byte[] apic=join(new byte[]{0},"image/jpeg".getBytes(StandardCharsets.US_ASCII),new byte[]{0,3,0},jpeg);frame(frames,"APIC",apic);
  byte[] body=payload.toByteArray();try(RandomAccessFile source=new RandomAccessFile(input,"r");OutputStream target=new BufferedOutputStream(new FileOutputStream(output))){
   long offset=0;if(source.length()>=10){byte[] old=new byte[10];source.readFully(old);if(old[0]=='I'&&old[1]=='D'&&old[2]=='3'){int size=0;for(int n=6;n<10;n++){if((old[n]&128)!=0)throw new IOException("Invalid ID3 size");size=(size<<7)|(old[n]&127);}offset=10L+size;if(old[3]==4&&(old[5]&16)!=0)offset+=10;if(offset>source.length())throw new IOException("Truncated ID3 tag");}}
   target.write(new byte[]{'I','D','3',3,0,0,(byte)(body.length>>21&127),(byte)(body.length>>14&127),(byte)(body.length>>7&127),(byte)(body.length&127)});target.write(body);copy(source,target,offset,source.length()-offset,monitor);
  }
 }
 private static final class Box {long offset,size;int header;String type;boolean zero;}
 private static Box readBox(RandomAccessFile f,long pos,long limit)throws IOException{
  if(limit-pos<8)throw new IOException("Truncated MP4 atom");f.seek(pos);Box b=new Box();b.offset=pos;b.size=Integer.toUnsignedLong(f.readInt());byte[] type=new byte[4];f.readFully(type);b.type=new String(type,StandardCharsets.ISO_8859_1);b.header=8;
  if(b.size==1){b.size=f.readLong();b.header=16;}else if(b.size==0){b.zero=true;b.size=limit-pos;}
  if(b.size<b.header||b.size>limit-pos)throw new IOException("Invalid MP4 atom size");return b;
 }
 private static byte[] appendMovieMetadata(byte[] body,byte[] meta)throws IOException{
  ByteArrayOutputStream result=new ByteArrayOutputStream();boolean found=false;
  for(int p=0;p<body.length;){if(body.length-p<8)throw new IOException("Truncated movie atom");int size=((body[p]&255)<<24)|((body[p+1]&255)<<16)|((body[p+2]&255)<<8)|(body[p+3]&255);if(size<8||size>body.length-p)throw new IOException("Invalid movie child");String type=new String(body,p+4,4,StandardCharsets.ISO_8859_1);
   if(type.equals("udta")){
    ByteArrayOutputStream udta=new ByteArrayOutputStream();int end=p+size;
    for(int q=p+8;q<end;){if(end-q<8)throw new IOException("Truncated metadata");int n=((body[q]&255)<<24)|((body[q+1]&255)<<16)|((body[q+2]&255)<<8)|(body[q+3]&255);if(n<8||n>end-q)throw new IOException("Invalid metadata child");String child=new String(body,q+4,4,StandardCharsets.ISO_8859_1);if(!child.equals("meta"))udta.write(body,q,n);q+=n;}
    if(!found){udta.write(meta);found=true;}result.write(atom("udta",udta.toByteArray()));
   }else result.write(body,p,size);p+=size;
  }
  if(!found)result.write(atom("udta",meta));return atom("moov",result.toByteArray());
 }
 public static void mp4(File input,File output,byte[] jpeg,String title,String artist,Monitor monitor)throws IOException{
  if(jpeg.length==0||jpeg.length>8*1024*1024)throw new IOException("Invalid cover size");
  try(RandomAccessFile source=new RandomAccessFile(input,"r")){
   ArrayList<Box> boxes=new ArrayList<>();Box movie=null;
   for(long pos=0;pos<source.length();){monitor.check();Box b=readBox(source,pos,source.length());if(b.type.equals("moof"))throw new IOException("Fragmented MP4 metadata is unsupported");if(b.type.equals("moov")){if(movie!=null)throw new IOException("Multiple movie atoms");movie=b;}boxes.add(b);pos+=b.size;}
   if(movie==null||movie.size-movie.header>MAX_METADATA)throw new IOException("MP4 movie metadata missing or too large");
   byte[] body=new byte[(int)(movie.size-movie.header)];source.seek(movie.offset+movie.header);source.readFully(body);byte[] updated=appendMovieMetadata(body,metadata(jpeg,title,artist));
   try(OutputStream target=new BufferedOutputStream(new FileOutputStream(output))){
    for(Box b:boxes){monitor.check();if(b==movie||b.zero){if(b.zero&&b.size>0xffffffffL)throw new IOException("Large zero-sized atom unsupported");source.seek(b.offset);byte[] header=new byte[b.header];source.readFully(header);if(b==movie){byte[] free="free".getBytes(StandardCharsets.US_ASCII);System.arraycopy(free,0,header,4,4);}if(b.zero){long n=b.size;for(int j=3;j>=0;j--){header[j]=(byte)n;n>>>=8;}}target.write(header);copy(source,target,b.offset+b.header,b.size-b.header,monitor);}else copy(source,target,b.offset,b.size,monitor);}
    monitor.check();target.write(updated);
   }
  }
 }
 private static void copy(RandomAccessFile source,OutputStream target,long offset,long size,Monitor monitor)throws IOException{source.seek(offset);byte[] buffer=new byte[262144];while(size>0){monitor.check();int n=source.read(buffer,0,(int)Math.min(size,buffer.length));if(n<0)throw new EOFException();target.write(buffer,0,n);size-=n;}}
}
