package com.jimmy.tube;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import org.schabi.newpipe.extractor.stream.*;
import org.schabi.newpipe.extractor.Image;
import org.schabi.newpipe.extractor.Page;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.playlist.PlaylistInfo;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
public class MainActivity extends Activity {
 private static final int BG=0xff0b1020,CARD=0xff161e33,TEXT=0xfff3f5ff,MUTED=0xffa5aec6,PINK=0xffff6577;
 private final ExecutorService executor=Executors.newSingleThreadExecutor();
 private EditText link;
 private LinearLayout body,infoPanel,libraryPanel,downloadPanel;
 private TextView status,title,details,jobText,libraryCount;
 private Button inspect,download,cancel;
 private ImageView image;
 private Spinner formats;
 private ProgressBar jobProgress;
 private ArrayList<TubeEngine.Choice> choices=new ArrayList<>();
 private String currentUrl="",currentTitle="";
 private String librarySnapshot="";
 private static final int LIBRARY_PAGE_SIZE=10;
 private int libraryPage=0;
 private volatile int libraryGeneration=0;
 private ScrollView pageScroll;
 private int generation=0;
 private boolean inspecting=false;
 private LinearLayout playlistPanel,playlistRows;
 private TextView playlistTitle,playlistCount;
 private Button playlistDownload,more,selectAll;
 private Spinner playlistFormat;
 private final ArrayList<PlaylistSupport.Item> playlistItems=new ArrayList<>();
 private String playlistUrl="";
 private Page nextPage;
 private int skipped=0;
 private long playlistTotal=-1;
 private final BroadcastReceiver receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){refreshJob();refreshLibrary();}};
 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);build();
  if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,new IntentFilter(DownloadService.EVENT),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,new IntentFilter(DownloadService.EVENT));
  if(state!=null){link.setText(state.getString("link",""));libraryPage=state.getInt("libraryPage",0);}else accept(getIntent());refreshJob();refreshLibrary();
 }
 @Override protected void onResume(){super.onResume();if(jobText!=null){refreshJob();refreshLibrary();}}
 @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);accept(i);}
 @Override protected void onSaveInstanceState(Bundle b){b.putString("link",link.getText().toString());b.putInt("libraryPage",libraryPage);super.onSaveInstanceState(b);}
 @Override protected void onDestroy(){generation++;libraryGeneration++;executor.shutdownNow();unregisterReceiver(receiver);super.onDestroy();}
 private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
 private GradientDrawable background(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 private TextView text(String value,int size,int color){TextView t=new TubeLanguage.Label(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.START);t.setPadding(0,dp(4),0,dp(4));return t;}
 private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
 private LinearLayout panel(){LinearLayout l=column();l.setPadding(dp(18),dp(15),dp(18),dp(15));l.setBackground(background(CARD,22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(14),0,0);body.addView(l,p);return l;}
 private Button button(String label,boolean primary){Button b=new TubeLanguage.Action(this);b.setText(label);b.setAllCaps(false);b.setTextSize(15);b.setTextColor(primary?BG:TEXT);b.setBackground(background(primary?PINK:0xff25324d,14));b.setMinHeight(dp(48));b.setPadding(dp(12),dp(8),dp(12),dp(8));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.setMargins(0,dp(10),0,0);b.setLayoutParams(p);return b;}
 private void build(){
  ScrollView scroll=new ScrollView(this);pageScroll=scroll;scroll.setFillViewport(true);scroll.setBackgroundColor(BG);scroll.setClipToPadding(false);body=column();body.setLayoutDirection(TubeLanguage.direction());body.setPadding(dp(20),dp(24),dp(20),dp(32));scroll.addView(body);setContentView(scroll);
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);body.addView(head);Button language=button("اللغة",false);language.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(48)));language.setOnClickListener(v->languageMenu());body.addView(language);
  TextView logo=text("↓",38,PINK);logo.setGravity(Gravity.CENTER);logo.setBackground(background(0xff302037,18));head.addView(logo,new LinearLayout.LayoutParams(dp(60),dp(60)));
  LinearLayout names=column();names.setPadding(dp(14),0,dp(14),0);head.addView(names,new LinearLayout.LayoutParams(0,-2,1));TextView brand=text("Jimmy Tube",26,TEXT);brand.setTypeface(null,Typeface.BOLD);names.addView(brand);names.addView(text("يوتيوب وتيك توك، على راحتك",13,MUTED));
  TextView intro=text("فيديوهاتك معك، حتى بدون إنترنت",24,TEXT);intro.setTypeface(null,Typeface.BOLD);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.setMargins(0,dp(24),0,0);body.addView(intro,ip);
  body.addView(text("شارك الرابط من يوتيوب أو تيك توك، أو ألصقه هنا واختر التنزيل.",14,MUTED));
  LinearLayout input=panel();input.addView(text("رابط الفيديو أو قائمة التشغيل",15,TEXT));
  link=new EditText(this);link.setSingleLine(true);link.setTextColor(TEXT);link.setHintTextColor(MUTED);link.setHint("https://youtu.be/…");link.setTextSize(15);link.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);link.setTextDirection(View.TEXT_DIRECTION_LTR);link.setPadding(dp(12),dp(12),dp(12),dp(12));link.setBackground(background(BG,12));input.addView(link,new LinearLayout.LayoutParams(-1,dp(52)));
  LinearLayout actions=new LinearLayout(this);input.addView(actions);
  inspect=button("فحص الرابط",true);Button paste=button("لصق الرابط",false);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(50),1);ap.setMargins(dp(4),dp(12),dp(4),0);actions.addView(inspect,ap);actions.addView(paste,new LinearLayout.LayoutParams(ap));inspect.setOnClickListener(v->inspectLink());paste.setOnClickListener(v->{ClipboardManager c=getSystemService(ClipboardManager.class);if(c.hasPrimaryClip()&&c.getPrimaryClip().getItemCount()>0){link.setText(c.getPrimaryClip().getItemAt(0).coerceToText(this));inspectLink();}else toast("الحافظة فارغة");});
  status=text("يوتيوب وShorts وقوائمه، وفيديوهات تيك توك العامة",12,MUTED);input.addView(status);
  infoPanel=panel();infoPanel.setVisibility(View.GONE);image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackground(background(BG,12));infoPanel.addView(image,new LinearLayout.LayoutParams(-1,dp(178)));
  title=text("",19,TEXT);((TubeLanguage.Label)title).preserveContent();title.setTypeface(null,Typeface.BOLD);infoPanel.addView(title);details=text("",13,MUTED);infoPanel.addView(details);
  infoPanel.addView(text("اختَر الصيغة والجودة",14,TEXT));formats=new Spinner(this);infoPanel.addView(formats,new LinearLayout.LayoutParams(-1,dp(52)));download=button("↓  تنزيل إلى الهاتف",true);infoPanel.addView(download);download.setOnClickListener(v->startDownload());Button original=button("فتح المصدر",false);infoPanel.addView(original);original.setOnClickListener(v->openOriginal(currentUrl));
  playlistPanel=panel();playlistPanel.setVisibility(View.GONE);
  playlistTitle=text("",19,TEXT);((TubeLanguage.Label)playlistTitle).preserveContent();playlistTitle.setTypeface(null,Typeface.BOLD);playlistPanel.addView(playlistTitle);
  playlistCount=text("",13,MUTED);playlistPanel.addView(playlistCount);
  playlistPanel.addView(text("اختَر الفيديوهات، ثم صيغة التنزيل",14,TEXT));
  playlistFormat=new Spinner(this);String[] batchFormats={"صوت MP3 · 192 kbps","فيديو MP4 · حتى 360p","فيديو MP4 · حتى 720p","فيديو MP4 · حتى 1080p","فيديو MP4 · أعلى جودة"};
  ArrayAdapter<String> batchAdapter=new TubeLanguage.Adapter<>(this,android.R.layout.simple_spinner_item,batchFormats);batchAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);playlistFormat.setAdapter(batchAdapter);playlistFormat.setSelection(2);playlistPanel.addView(playlistFormat,new LinearLayout.LayoutParams(-1,dp(52)));
  selectAll=button("تحديد الكل / إلغاء التحديد",false);playlistPanel.addView(selectAll);selectAll.setOnClickListener(v->{boolean all=true;for(PlaylistSupport.Item x:playlistItems)if(!x.selected)all=false;for(PlaylistSupport.Item x:playlistItems)x.selected=!all;renderPlaylist();});
  ScrollView listScroll=new PlaylistScrollView(this);playlistRows=column();listScroll.addView(playlistRows);playlistPanel.addView(listScroll,new LinearLayout.LayoutParams(-1,dp(320)));
  more=button("تحميل المزيد من القائمة",false);playlistPanel.addView(more);more.setOnClickListener(v->loadPlaylistPage(false));
  playlistDownload=button("↓ تنزيل المحدد",true);playlistPanel.addView(playlistDownload);playlistDownload.setOnClickListener(v->startPlaylist());
  playlistPanel.addView(text("تُنزل العناصر المحددة بالتتابع مع الغلاف والصوت الأصلي. الجودة الأقرب المتاحة تُستخدم عند غياب الجودة المختارة. تحديد الكل يشمل العناصر المحمّلة فقط؛ استخدم تحميل المزيد لبقية القائمة.",12,MUTED));
  downloadPanel=panel();downloadPanel.addView(text("حالة التنزيل",17,TEXT));jobText=text("",14,MUTED);downloadPanel.addView(jobText);jobProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);jobProgress.setMax(100);jobProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(PINK));downloadPanel.addView(jobProgress,new LinearLayout.LayoutParams(-1,dp(10)));cancel=button("إلغاء التنزيل",false);downloadPanel.addView(cancel);cancel.setOnClickListener(v->{cancel.setEnabled(false);startService(new Intent(this,DownloadService.class).setAction(DownloadService.CANCEL));});
  libraryPanel=panel();libraryCount=text("مكتبتي",20,TEXT);libraryCount.setTypeface(null,Typeface.BOLD);libraryPanel.addView(libraryCount);
  TextView footer=text("Jimmy Tube · 2.2\nالملفات تُحفظ في Download/JimmyTube\nتطبيق مستقل، غير تابع ليوتيوب أو تيك توك أو Snaptube",12,MUTED);footer.setGravity(Gravity.CENTER);footer.setPadding(0,dp(25),0,0);body.addView(footer);
 }
 private void languageMenu(){new AlertDialog.Builder(this).setTitle(TubeStrings.t("اللغة")).setSingleChoiceItems(new String[]{"English","العربية"},TubeStrings.english?0:1,(dialog,which)->{TubeLanguage.set(this,which==0);body.setLayoutDirection(TubeLanguage.direction());TubeLanguage.refresh(body);librarySnapshot="";refreshLibrary();refreshJob();dialog.dismiss();}).setNegativeButton(TubeStrings.t("إلغاء"),null).show();}
 private void accept(Intent i){if(Intent.ACTION_SEND.equals(i.getAction())){String s=i.getStringExtra(Intent.EXTRA_TEXT);if(s!=null){link.setText(s);inspectLink();}}}
 private void inspectLink(){
  if(inspecting)return;if(DownloadService.busy){toast("انتظر اكتمال التنزيل الحالي أو ألغِه");return;}
  final String url;try{String pl=PlaylistSupport.canonical(link.getText().toString());if(pl!=null){playlistUrl=pl;loadPlaylistPage(true);return;}url=TubeEngine.sourceUrl(link.getText().toString());}catch(Exception e){status.setText(Library.friendly(e));return;}
  ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(link.getWindowToken(),0);
  inspecting=true;inspect.setEnabled(false);inspect.setText("جارٍ الفحص…");status.setText("أبحث عن معلومات الفيديو وصيغ التنزيل المتاحة…");infoPanel.setVisibility(View.GONE);playlistPanel.setVisibility(View.GONE);final int token=++generation;
  executor.execute(()->{
   try{
    MediaInfo info=TubeEngine.inspect(url);ArrayList<TubeEngine.Choice> available=new ArrayList<>(info.choices);if(available.isEmpty())throw new IllegalArgumentException("تعذّر تحديد صوت أصلي مدعوم لهذا الفيديو؛ لن أختار نسخة مدبلجة تلقائيًا. البث المباشر غير مدعوم.");
    runOnUiThread(()->{if(isFinishing()||token!=generation)return;currentUrl=info.getUrl();currentTitle=info.getName();choices=available;title.setText(currentTitle);long duration=info.getDuration();details.setText(info.getUploaderName()+"  ·  "+(duration>=3600?String.format(Locale.US,"%d:%02d:%02d",duration/3600,duration/60%60,duration%60):String.format(Locale.US,"%d:%02d",duration/60,duration%60)));
     ArrayAdapter<TubeEngine.Choice> adapter=new TubeLanguage.Adapter<>(this,android.R.layout.simple_spinner_item,choices);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);formats.setAdapter(adapter);int selection=0;for(int n=0;n<choices.size();n++)if(choices.get(n).label.contains("720p")){selection=n;break;}formats.setSelection(selection);image.setImageDrawable(null);infoPanel.setVisibility(View.VISIBLE);status.setText("جاهز — "+choices.size()+" خيارات تنزيل متاحة · الصوت الأصلي");finishInspect();});
    String thumb=null;for(Image im:info.getThumbnails())if(im.getUrl().startsWith("https://"))thumb=im.getUrl();
    if(thumb!=null){HttpURLConnection c=(HttpURLConnection)new URL(thumb).openConnection();c.setRequestProperty("User-Agent",TubeEngine.UA);if(TikTokEngine.isLink(info.getUrl()))c.setRequestProperty("Referer",info.getUrl());c.setConnectTimeout(12000);c.setReadTimeout(12000);try(InputStream in=c.getInputStream()){BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=2;Bitmap bitmap=BitmapFactory.decodeStream(in,null,options);runOnUiThread(()->{if(token==generation&&!isFinishing())image.setImageBitmap(bitmap);});}finally{c.disconnect();}}
   }catch(Exception e){runOnUiThread(()->{if(token!=generation||isFinishing())return;if(inspecting){status.setText(Library.friendly(e));finishInspect();}});}
  });
 }
 private void loadPlaylistPage(boolean first){
  if(inspecting||DownloadService.busy)return;
  ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(link.getWindowToken(),0);
  inspecting=true;inspect.setText("جارٍ الفحص…");refreshJob();more.setEnabled(false);status.setText(first?"جلب قائمة التشغيل…":"جلب الصفحة التالية…");
  if(first){playlistItems.clear();nextPage=null;skipped=0;playlistTotal=-1;playlistPanel.setVisibility(View.GONE);infoPanel.setVisibility(View.GONE);}
  final int token=++generation;final String url=playlistUrl;final Page page=nextPage;
  executor.execute(()->{try{
   final java.util.List<StreamInfoItem> items;final Page next;final String name;final long total;
   if(first){PlaylistInfo info=PlaylistInfo.getInfo(url);items=info.getRelatedItems();next=info.hasNextPage()?info.getNextPage():null;name=info.getName();total=info.getStreamCount();}
   else{org.schabi.newpipe.extractor.ListExtractor.InfoItemsPage<StreamInfoItem> result=PlaylistInfo.getMoreItems(ServiceList.YouTube,url,page);items=result.getItems();next=result.hasNextPage()?result.getNextPage():null;name=null;total=-1;}
   runOnUiThread(()->{if(isFinishing()||token!=generation)return;skipped+=PlaylistSupport.append(playlistItems,items);nextPage=playlistItems.size()>=PlaylistSupport.LIMIT?null:next;if(first){playlistTitle.setText(name);playlistTotal=total;}playlistPanel.setVisibility(View.VISIBLE);renderPlaylist();status.setText("قائمة التشغيل جاهزة — اختَر ما تريد تنزيله");finishInspect();});
  }catch(Exception e){runOnUiThread(()->{if(isFinishing()||token!=generation)return;status.setText(Library.friendly(e));finishInspect();});}});
 }
 private void renderPlaylist(){
  playlistRows.removeAllViews();int n=0;
  for(PlaylistSupport.Item x:playlistItems){CheckBox c=new CheckBox(this);c.setText((++n)+". "+x.title);c.setTextColor(TEXT);c.setButtonTintList(android.content.res.ColorStateList.valueOf(PINK));c.setChecked(x.selected);c.setPadding(0,dp(8),0,dp(8));playlistRows.addView(c,new LinearLayout.LayoutParams(-1,-2));c.setOnCheckedChangeListener((b,checked)->{x.selected=checked;updatePlaylistCount();});}
  if(playlistItems.isEmpty())playlistRows.addView(text("لا توجد فيديوهات قابلة للتنزيل في هذه الصفحة.",14,MUTED));
  updatePlaylistCount();refreshJob();
 }
 private void updatePlaylistCount(){int count=0;for(PlaylistSupport.Item x:playlistItems)if(x.selected)count++;
  playlistCount.setText("المحمّل: "+playlistItems.size()+(playlistTotal>0?" / "+playlistTotal:"")+" · المحدد: "+count+(skipped>0?" · تم تجاهل "+skipped+" عناصر مكررة أو غير مدعومة":"")+(playlistItems.size()>=PlaylistSupport.LIMIT?"\nهذا الإصدار يدعم أول 500 فيديو من القائمة.":""));
  playlistDownload.setText("↓ تنزيل المحدد ("+count+")");playlistDownload.setEnabled(count>0&&!DownloadService.busy&&!inspecting);
 }
 private void startPlaylist(){
  if(DownloadService.busy||inspecting)return;ArrayList<String> urls=new ArrayList<>(),titles=new ArrayList<>();for(PlaylistSupport.Item x:playlistItems)if(x.selected){urls.add(x.url);titles.add(x.title);}if(urls.isEmpty()){toast("اختَر فيديو واحدًا على الأقل");return;}
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9);
  int option=playlistFormat.getSelectedItemPosition();int[] heights={0,360,720,1080,2160};
  Intent i=new Intent(this,DownloadService.class).putStringArrayListExtra("urls",urls).putStringArrayListExtra("titles",titles).putExtra("title",playlistTitle.getText().toString()).putExtra("mode",option==0?"mp3":"mp4").putExtra("height",heights[option]);
  try{startForegroundService(i);playlistDownload.setEnabled(false);toast("بدأ تنزيل "+urls.size()+" عناصر بالتتابع");}catch(Exception e){toast(Library.friendly(e));}
 }
 private void finishInspect(){inspecting=false;inspect.setEnabled(!DownloadService.busy);inspect.setText("فحص الرابط");refreshJob();}
 private void startDownload(){if(DownloadService.busy){toast("يوجد تنزيل جارٍ");return;}if(choices.isEmpty())return;if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9);
  TubeEngine.Choice choice=choices.get(formats.getSelectedItemPosition());Intent i=new Intent(this,DownloadService.class).putExtra("url",currentUrl).putExtra("title",currentTitle).putExtra("choice",choice.label);try{startForegroundService(i);download.setEnabled(false);toast("بدأ التنزيل");}catch(Exception e){toast(Library.friendly(e));}
 }
 private void refreshJob(){boolean busy=DownloadService.busy;((TubeLanguage.Label)jobText).preserveContent();jobText.setText((busy?DownloadService.title+"\n":"")+TubeStrings.t(DownloadService.state));jobProgress.setIndeterminate(busy&&DownloadService.percent<0);jobProgress.setProgress(Math.max(0,DownloadService.percent));jobProgress.setVisibility(busy||DownloadService.percent==100?View.VISIBLE:View.GONE);cancel.setVisibility(busy?View.VISIBLE:View.GONE);cancel.setEnabled(busy);download.setEnabled(!busy);inspect.setEnabled(!busy&&!inspecting);more.setVisibility(nextPage!=null?View.VISIBLE:View.GONE);more.setEnabled(!busy&&!inspecting);selectAll.setEnabled(!busy&&!inspecting);playlistFormat.setEnabled(!busy&&!inspecting);if(playlistDownload!=null)updatePlaylistCount();}
 private String size(long bytes){return String.format(Locale.US,"%.1f MB",bytes/1048576.0);}
 private void changeLibraryPage(int page){
  libraryPage=page;refreshLibrary();
  pageScroll.post(()->{if(!isDestroyed())pageScroll.smoothScrollTo(0,libraryPanel.getTop());});
 }
 private void libraryPager(int total,int pages){
  LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.setMargins(0,dp(12),0,dp(6));libraryPanel.addView(nav,np);
  Button previous=button("السابق",false),next=button("التالي",false);previous.setEnabled(libraryPage>0);next.setEnabled(libraryPage+1<pages);previous.setAlpha(previous.isEnabled()?1f:0.4f);next.setAlpha(next.isEnabled()?1f:0.4f);
  previous.setOnClickListener(v->changeLibraryPage(libraryPage-1));next.setOnClickListener(v->changeLibraryPage(libraryPage+1));
  LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(48),1);nav.addView(previous,bp);
  TextView number=text("صفحة "+(libraryPage+1)+" / "+pages+"\n"+(libraryPage*LIBRARY_PAGE_SIZE+1)+"–"+Math.min(total,(libraryPage+1)*LIBRARY_PAGE_SIZE)+" من "+total,12,MUTED);number.setGravity(Gravity.CENTER);nav.addView(number,new LinearLayout.LayoutParams(0,-2,1.2f));nav.addView(next,new LinearLayout.LayoutParams(bp));
 }
 private void refreshLibrary(){JSONArray entries=Library.read(this);int pages=Math.max(1,(entries.length()+LIBRARY_PAGE_SIZE-1)/LIBRARY_PAGE_SIZE);libraryPage=Math.max(0,Math.min(libraryPage,pages-1));String snapshot=libraryPage+":"+entries.toString();if(snapshot.equals(librarySnapshot))return;librarySnapshot=snapshot;libraryGeneration++;while(libraryPanel.getChildCount()>1)libraryPanel.removeViewAt(1);libraryCount.setText("مكتبتي  ·  "+entries.length());if(entries.length()==0){libraryPanel.addView(text("تنزيلاتك ستظهر هنا.\nافتح الفيديو أو شاركه بعد اكتمال التنزيل.",14,MUTED));return;}
  libraryPager(entries.length(),pages);
  for(int n=libraryPage*LIBRARY_PAGE_SIZE;n<Math.min(entries.length(),(libraryPage+1)*LIBRARY_PAGE_SIZE);n++){JSONObject entry=entries.optJSONObject(n);if(entry==null)continue;LinearLayout row=column();row.setPadding(dp(12),dp(12),dp(12),dp(12));row.setBackground(background(BG,14));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,dp(12),0,0);libraryPanel.addView(row,rp);{ImageView cover=new ImageView(this);cover.setScaleType(ImageView.ScaleType.CENTER_CROP);row.addView(cover,new LinearLayout.LayoutParams(-1,dp(140)));loadCover(cover,entry.optString("uri"),entry.optString("coverUri"));}TextView name=text((entry.optString("mime").startsWith("audio")?"♫  ":"▶  ")+entry.optString("title"),16,TEXT);((TubeLanguage.Label)name).preserveContent();name.setMaxLines(3);row.addView(name);row.addView(text(entry.optString("quality")+"  ·  "+size(entry.optLong("size")),12,MUTED));Button open=button("تشغيل  /  خيارات",false);row.addView(open);open.setOnClickListener(v->fileOptions(entry));}
  libraryPager(entries.length(),pages);
  }
 private void loadCover(ImageView view,String mediaUri,String legacyUri){final int token=libraryGeneration;executor.execute(()->{if(token!=libraryGeneration||isDestroyed())return;Bitmap bitmap=EmbeddedCover.read(this,mediaUri,legacyUri);runOnUiThread(()->{if(!isDestroyed()&&token==libraryGeneration){if(bitmap==null)view.setVisibility(View.GONE);else view.setImageBitmap(bitmap);}});});}
 private void showCover(JSONObject entry){executor.execute(()->{Bitmap bitmap=EmbeddedCover.read(this,entry.optString("uri"),entry.optString("coverUri"));runOnUiThread(()->{if(isDestroyed())return;if(bitmap==null){toast("لا يوجد غلاف قابل للعرض في هذا الملف");return;}ImageView picture=new ImageView(this);picture.setImageBitmap(bitmap);picture.setAdjustViewBounds(true);picture.setScaleType(ImageView.ScaleType.FIT_CENTER);new AlertDialog.Builder(this).setTitle(TubeStrings.t("غلاف الملف")).setView(picture).setPositiveButton(TubeStrings.t("إغلاق"),null).show();});});}
 private void fileOptions(JSONObject entry){String[] options={"تشغيل داخل التطبيق","مشاركة الملف","فتح الفيديو الأصلي","إزالة من المكتبة","حذف الملف من الهاتف","عرض صورة الغلاف"};for(int n=0;n<options.length;n++)options[n]=TubeStrings.t(options[n]);new AlertDialog.Builder(this).setTitle(entry.optString("title")).setItems(options,(d,which)->{Uri uri=Uri.parse(entry.optString("uri"));if(which==0){startActivity(new Intent(this,PlayerActivity.class).setData(uri).putExtra("title",entry.optString("title")).putExtra("coverUri",entry.optString("coverUri")).putExtra("audio",entry.optString("mime").startsWith("audio")));}else if(which==1){Intent i=new Intent(Intent.ACTION_SEND).setType(entry.optString("mime")).putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("Jimmy Tube",uri));try{startActivity(Intent.createChooser(i,TubeStrings.t("مشاركة الملف")));}catch(Exception e){toast("لا يوجد تطبيق مناسب لمشاركة الملف");}}
   else if(which==2)openOriginal(entry.optString("url"));else if(which==3){Library.remove(this,uri.toString());refreshLibrary();}else if(which==5){showCover(entry);}else new AlertDialog.Builder(this).setTitle(TubeStrings.t("حذف الملف؟")).setMessage(entry.optString("coverUri").isEmpty()?TubeStrings.t("سيُحذف هذا التنزيل من الهاتف."):TubeStrings.t("سيُحذف هذا التنزيل وصورة الغلاف القديمة المنفصلة من الهاتف.")).setNegativeButton(TubeStrings.t("إلغاء"),null).setPositiveButton(TubeStrings.t("حذف"),(dialog,w)->{try{getContentResolver().delete(uri,null,null);if(!entry.optString("coverUri").isEmpty())getContentResolver().delete(Uri.parse(entry.optString("coverUri")),null,null);Library.remove(this,uri.toString());refreshLibrary();}catch(Exception e){toast("تعذّر الحذف؛ يمكنك حذفه من تطبيق الملفات.");}}).show();}).show();}
 private void openOriginal(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){toast("لا يوجد تطبيق لفتح الرابط");}}
 private void toast(String s){Toast.makeText(this,TubeStrings.t(s),Toast.LENGTH_LONG).show();}
}
