package com.jimmy.tube;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import org.json.JSONObject;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.Image;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.*;
public class DownloadService extends Service {
 public static final String EVENT="com.jimmy.tube.STATE",CANCEL="cancel";
 public static volatile boolean busy=false;
 public static volatile int percent=-1;
 public static volatile String state="جاهز للتنزيل", title="";
 private volatile boolean cancelled=false;
 private volatile HttpURLConnection activeConnection;
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private PowerManager.WakeLock wake;
 private long lastEvent=0;
 private int currentStart;
 private NotificationManager notifications;
 private String batchPrefix="";
 private String mediaReferer=null;
 private String mediaCookie=null;
 @Override public void onCreate(){super.onCreate();notifications=getSystemService(NotificationManager.class);notifications.createNotificationChannel(new NotificationChannel("downloads",TubeStrings.t("تنزيلات Jimmy Tube"),NotificationManager.IMPORTANCE_LOW));}
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent i,int flags,int id){
  if(i==null){stopSelf(id);return START_NOT_STICKY;}
  if(CANCEL.equals(i.getAction())){cancelled=true;HttpURLConnection c=activeConnection;if(c!=null)c.disconnect();if(!busy)stopSelf(id);return START_NOT_STICKY;}
  if(busy)return START_NOT_STICKY;
  currentStart=id;cancelled=false;busy=true;title=i.getStringExtra("title");if(title==null)title="فيديو يوتيوب";
  state="تحضير التنزيل…";percent=-1;
  try{startForeground(41,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);}catch(Exception e){busy=false;state=Library.friendly(e);broadcast();stopSelf();return START_NOT_STICKY;}
  wake=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"JimmyTube:download");wake.acquire(6*60*60*1000L);
  worker.execute(()->runQueue(i));
  return START_NOT_STICKY;
 }
 private Notification notification(){
  PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  PendingIntent cancel=PendingIntent.getService(this,1,new Intent(this,DownloadService.class).setAction(CANCEL),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  Notification.Builder b=new Notification.Builder(this,"downloads").setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle(title).setContentText(TubeStrings.t(state)).setContentIntent(open).setOnlyAlertOnce(true).setOngoing(busy);
  if(busy)b.setProgress(100,Math.max(0,percent),percent<0).addAction(new Notification.Action.Builder(null,TubeStrings.t("إلغاء"),cancel).build());
  return b.build();
 }
 private void broadcast(){sendBroadcast(new Intent(EVENT).setPackage(getPackageName()));}
 private void report(String text,int p,boolean force){state=batchPrefix+text;percent=p;long now=System.currentTimeMillis();if(force||now-lastEvent>650){lastEvent=now;broadcast();notifications.notify(41,notification());}}
 private void check()throws InterruptedIOException{if(cancelled||Thread.currentThread().isInterrupted())throw new InterruptedIOException("cancelled");}
 private void runQueue(Intent intent){
  int completed=0,failed=0,warnings=0;String lastFailure="";
  ArrayList<String> urls=intent.getStringArrayListExtra("urls");boolean batch=urls!=null;
  final String destination=Environment.DIRECTORY_DOWNLOADS+"/JimmyTube"+(batch?"/"+PlaylistSupport.folderName(intent.getStringExtra("title")):"");
  if(!batch){urls=new ArrayList<>();urls.add(intent.getStringExtra("url"));}
  try{
   if(urls.isEmpty()||urls.size()>PlaylistSupport.LIMIT)throw new IllegalArgumentException("عدد عناصر القائمة غير صالح.");
   for(int n=0;n<urls.size();n++){
    check();batchPrefix=batch?"["+(n+1)+" / "+urls.size()+"] ":"";
    ArrayList<String> names=intent.getStringArrayListExtra("titles");title=names!=null&&n<names.size()?names.get(n):intent.getStringExtra("title");
    try{String warning=runDownload(urls.get(n),intent.getStringExtra("choice"),batch?intent.getStringExtra("mode"):null,intent.getIntExtra("height",720),destination);completed++;if(!warning.isEmpty())warnings++;}
    catch(Exception e){check();failed++;lastFailure=Library.friendly(e);if(!batch)throw e;report("تعذّر تنزيل العنصر؛ الانتقال إلى التالي",-1,true);}
   }
   check();batchPrefix="";
   report(batch?"انتهت القائمة ✓ — اكتمل "+completed+"، تعذّر "+failed+"\nمحفوظ في "+destination+(warnings>0?"، ملاحظات غلاف: "+warnings:"")+(failed>0?"\nآخر مشكلة: "+lastFailure:""):"اكتمل التنزيل ✓ — محفوظ في "+destination+(warnings>0?" — تعذّر جلب أو تضمين إحدى صور الغلاف":""),100,true);
  }catch(Exception e){batchPrefix="";report(cancelled?"أُلغي التنزيل — الملفات المكتملة محفوظة ("+completed+")":Library.friendly(e),-1,true);}
  finally{batchPrefix="";mediaCookie=null;mediaReferer=null;if(wake!=null&&wake.isHeld())wake.release();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();busy=false;broadcast();}
 }
 private String runDownload(String url,String label,String mode,int height,String destination)throws Exception{
  File folder=null;Uri pending=null;String artworkWarning="";
  try{
   report("تحديث روابط الفيديو…",-1,true);check();
   MediaInfo info=TubeEngine.inspect(url);check();
   TubeEngine.Choice selected=null;
   if(mode!=null)selected=PlaylistSupport.choose(info.choices,mode,height);else for(TubeEngine.Choice x:info.choices)if(x.label.equals(label)){selected=x;break;}
   if(selected==null)throw new IllegalArgumentException("هذه الجودة لم تعد متاحة؛ أعد فحص الفيديو واختر جودة أخرى.");
   title=info.getName();mediaReferer=selected.referer;mediaCookie=selected.cookie;
   folder=new File(getCacheDir(),"job-"+UUID.randomUUID());if(!folder.mkdirs())throw new IOException("Cannot create download folder");
   File cover=null;
   try{report("جلب الصورة المصغّرة…",-1,true);cover=fetchCover(info,folder);}catch(InterruptedIOException e){throw e;}catch(Exception e){check();artworkWarning=" — تعذّر جلب صورة الغلاف";}
   File finished;
   if("mp3".equals(selected.extension)){
    File source=new File(folder,mediaReferer==null?"source.m4a":"source.mp4");download(selected.audio,source,"تنزيل الصوت",0,60);
    finished=new File(folder,"complete.mp3");report("تحويل الصوت إلى MP3…",60,true);
    Mp3Converter.convert(source,finished,new Mp3Converter.Monitor(){public void check()throws InterruptedIOException{DownloadService.this.check();}public void progress(int p){report("تحويل الصوت إلى MP3 · "+p+"%",60+p*28/100,false);}});check();
   }else if(selected.needsMux()){
    File video=new File(folder,"video.mp4"),audio=new File(folder,"audio.m4a");
    download(selected.video,video,"تنزيل الفيديو",0,68);
    download(selected.audio,audio,"تنزيل الصوت",68,18);
    finished=new File(folder,"complete.mp4");report("دمج الصوت والفيديو…",87,true);mux(video,audio,finished);check();
   }else{finished=new File(folder,"complete."+selected.extension);download(selected.video!=null?selected.video:selected.audio,finished,"تنزيل الملف",0,88);}
   check();
   if(cover!=null){
    report("إضافة صورة الغلاف إلى الملف…",89,true);
    try{byte[] jpeg=java.nio.file.Files.readAllBytes(cover.toPath());File tagged=new File(folder,"with-cover."+selected.extension);if("mp3".equals(selected.extension))ArtworkTags.mp3(finished,tagged,jpeg,title,info.getUploaderName(),()->check());else ArtworkTags.mp4(finished,tagged,jpeg,title,info.getUploaderName(),()->check());finished=tagged;}
    catch(InterruptedIOException e){throw e;}catch(Exception e){check();artworkWarning=" — تعذّر تضمين صورة الغلاف داخل الملف";}
   }
   report("حفظ الملف في التنزيلات…",90,true);
   String name=title.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_").trim();if(name.length()>100)name=name.substring(0,100);if(name.isEmpty())name="YouTube";
   String baseName=name+" - "+System.currentTimeMillis();name=baseName+"."+selected.extension;
   ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,name);values.put(MediaStore.Downloads.MIME_TYPE,selected.mime);values.put(MediaStore.Downloads.RELATIVE_PATH,destination);values.put(MediaStore.Downloads.IS_PENDING,1);
   pending=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(pending==null)throw new IOException("Cannot create output file");
   try(InputStream in=new FileInputStream(finished);OutputStream out=getContentResolver().openOutputStream(pending,"w")){if(out==null)throw new IOException("Cannot write output");byte[] b=new byte[262144];int n;long copied=0;while((n=in.read(b))!=-1){check();out.write(b,0,n);copied+=n;report("حفظ الملف…",90+(int)(copied*9/Math.max(1,finished.length())),false);}}
   check();values.clear();values.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(pending,values,null,null);
   JSONObject entry=new JSONObject();entry.put("title",title);entry.put("name",name);entry.put("uri",pending.toString());entry.put("mime",selected.mime);entry.put("size",finished.length());entry.put("quality",selected.label);entry.put("url",url);entry.put("time",System.currentTimeMillis());Library.add(this,entry);pending=null;
   report("اكتمل تنزيل العنصر ✓"+artworkWarning,100,true);return artworkWarning;
  }
  finally{
   if(pending!=null)try{getContentResolver().delete(pending,null,null);}catch(Exception ignored){}
   if(folder!=null){File[] files=folder.listFiles();if(files!=null)for(File f:files)f.delete();folder.delete();}
  }
 }
 private File fetchCover(MediaInfo info,File folder)throws Exception{
  ArrayList<Image> images=new ArrayList<>(info.getThumbnails());images.sort((a,b)->Integer.compare(b.getWidth(),a.getWidth()));
  for(Image image:images){check();if(!image.getUrl().startsWith("https://"))continue;
   HttpURLConnection c=(HttpURLConnection)new URL(image.getUrl()).openConnection();activeConnection=c;c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent",TubeEngine.UA);if(mediaReferer!=null)c.setRequestProperty("Referer",mediaReferer);
   try{if(c.getResponseCode()!=200)continue;ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1){check();bytes.write(b,0,n);if(bytes.size()>8*1024*1024)throw new IOException("Cover too large");}}
    byte[] raw=bytes.toByteArray();BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(raw,0,raw.length,options);if(options.outWidth<=0||options.outHeight<=0)continue;options.inJustDecodeBounds=false;options.inSampleSize=1;while(options.outWidth/options.inSampleSize>1280||options.outHeight/options.inSampleSize>1280)options.inSampleSize*=2;
    Bitmap bitmap=BitmapFactory.decodeByteArray(raw,0,raw.length,options);if(bitmap==null)continue;File cover=new File(folder,"cover.jpg");try(OutputStream out=new FileOutputStream(cover)){if(!bitmap.compress(Bitmap.CompressFormat.JPEG,90,out))throw new IOException("Cannot encode JPEG cover");}finally{bitmap.recycle();}check();return cover;
   }catch(InterruptedIOException e){throw e;}catch(IOException e){check();}finally{activeConnection=null;c.disconnect();}
  }
  throw new IOException("No usable thumbnail");
 }
 private void download(String url,File file,String label,int base,int span)throws Exception{
  MediaTransfer.download(url,file,new MediaTransfer.Monitor(){
   public void check()throws InterruptedIOException{DownloadService.this.check();}
   public void connection(HttpURLConnection c){activeConnection=c;}
   public void progress(long done,long total){int p=total>0?base+(int)(Math.min(done,total)*span/total):-1;report(label+" · "+String.format(Locale.US,"%.1f",done/1048576.0)+" MB"+(total>0?" / "+String.format(Locale.US,"%.1f",total/1048576.0)+" MB":""),p,false);}
  },mediaReferer,mediaCookie);
 }
 private void mux(File video,File audio,File output)throws Exception{
  MediaExtractor v=new MediaExtractor(),a=new MediaExtractor();MediaMuxer m=null;boolean started=false;
  try{v.setDataSource(video.getAbsolutePath());a.setDataSource(audio.getAbsolutePath());m=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
   int vi=findTrack(v,"video/"),ai=findTrack(a,"audio/");
   int vt=m.addTrack(v.getTrackFormat(vi)),at=m.addTrack(a.getTrackFormat(ai));v.selectTrack(vi);a.selectTrack(ai);m.start();started=true;copyTrack(v,m,vt);copyTrack(a,m,at);m.stop();started=false;
  }finally{v.release();a.release();if(m!=null){if(started)try{m.stop();}catch(Exception ignored){}m.release();}}
 }
 private int findTrack(MediaExtractor e,String prefix)throws IOException{for(int t=0;t<e.getTrackCount();t++){String mime=e.getTrackFormat(t).getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith(prefix))return t;}throw new IOException("Missing "+prefix+" track");}
 private void copyTrack(MediaExtractor e,MediaMuxer m,int track)throws Exception{ByteBuffer buf=ByteBuffer.allocateDirect(8*1024*1024);MediaCodec.BufferInfo bi=new MediaCodec.BufferInfo();while(true){check();buf.clear();long sample=e.getSampleSize();if(sample<0)break;if(sample>buf.capacity()){if(sample>32*1024*1024)throw new IOException("Media sample too large");buf=ByteBuffer.allocateDirect((int)sample);}int size=e.readSampleData(buf,0);if(size<0)break;bi.set(0,size,e.getSampleTime(),(e.getSampleFlags()&MediaExtractor.SAMPLE_FLAG_SYNC)!=0?MediaCodec.BUFFER_FLAG_KEY_FRAME:0);m.writeSampleData(track,buf,bi);e.advance();}}
 @Override public void onTimeout(int startId,int fgsType){cancelled=true;HttpURLConnection c=activeConnection;if(c!=null)c.disconnect();state="انتهت مدة التنزيل المسموحة؛ أعد المحاولة.";stopSelf();}
 @Override public void onDestroy(){cancelled=true;HttpURLConnection c=activeConnection;if(c!=null)c.disconnect();worker.shutdownNow();busy=false;if(wake!=null&&wake.isHeld())wake.release();super.onDestroy();}
}
