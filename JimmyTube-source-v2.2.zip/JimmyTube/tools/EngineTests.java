import com.jimmy.tube.*;
import com.sun.net.httpserver.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class EngineTests {
 static void require(boolean b,String message){if(!b)throw new AssertionError(message);}
 static int tests=0;
 public static void main(String[] args)throws Exception{
  String id="aqz-KE-bpKQ",canonical="https://www.youtube.com/watch?v="+id;
  for(String url:new String[]{"https://youtu.be/"+id+"?si=123","https://m.youtube.com/watch?v="+id+"&t=30","https://www.youtube.com/shorts/"+id,"شاهد الفيديو https://www.youtube.com/watch?v="+id}){require(TubeEngine.canonical(url).equals(canonical),"canonical "+url);tests++;}
  for(String url:new String[]{"https://youtube.com.evil.com/watch?v="+id,"https://youtube.com@evil.com/watch?v="+id,"https://example.com/"+id,"https://youtube.com/playlist?list=123","https://youtu.be/short","no url"}){boolean rejected=false;try{TubeEngine.canonical(url);}catch(IllegalArgumentException e){rejected=true;}require(rejected,"must reject "+url);tests++;}
  byte[] bytes=new byte[5*1024*1024+187];new Random(42).nextBytes(bytes);AtomicInteger requests=new AtomicInteger();
  HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
  server.createContext("/range",e->{requests.incrementAndGet();String range=e.getRequestHeaders().getFirst("Range");String[] r=range.substring(6).split("-");int start=Integer.parseInt(r[0]),end=Math.min(bytes.length-1,Integer.parseInt(r[1]));e.getResponseHeaders().add("Content-Range","bytes "+start+"-"+end+"/"+bytes.length);e.getResponseHeaders().add("Content-Type","video/mp4");e.sendResponseHeaders(206,end-start+1);try(OutputStream out=e.getResponseBody()){out.write(bytes,start,end-start+1);}catch(IOException ignored){}});
  server.createContext("/full",e->{e.getResponseHeaders().add("Content-Type","audio/mp4");e.sendResponseHeaders(200,bytes.length);try(OutputStream out=e.getResponseBody()){out.write(bytes);}});
  server.createContext("/bad",e->{e.sendResponseHeaders(403,-1);e.close();});
  server.createContext("/html",e->{e.getResponseHeaders().add("Content-Type","text/html");e.sendResponseHeaders(200,10);try(OutputStream out=e.getResponseBody()){out.write(new byte[10]);}});
  server.start();String base="http://127.0.0.1:"+server.getAddress().getPort();File folder=new File("JimmyTube/build/probe");folder.mkdirs();
  MediaTransfer.Monitor monitor=new MediaTransfer.Monitor(){public void check(){}public void connection(HttpURLConnection c){}public void progress(long d,long t){}};
  try{
   File ranged=new File(folder,"test-range.bin");MediaTransfer.download(base+"/range",ranged,monitor);require(Arrays.equals(bytes,java.nio.file.Files.readAllBytes(ranged.toPath())),"ranged content exact");require(requests.get()==3,"must use 3 chunks");tests++;ranged.delete();
   File full=new File(folder,"test-full.bin");MediaTransfer.download(base+"/full",full,monitor);require(Arrays.equals(bytes,java.nio.file.Files.readAllBytes(full.toPath())),"full response exact");tests++;full.delete();
   for(String path:new String[]{"/bad","/html"}){File f=new File(folder,"test-reject.bin");boolean rejected=false;try{MediaTransfer.download(base+path,f,monitor);}catch(IOException e){rejected=true;}require(rejected,"reject "+path);tests++;f.delete();}
   File cancelled=new File(folder,"test-cancel.bin");boolean stopped=false;try{MediaTransfer.download(base+"/range",cancelled,new MediaTransfer.Monitor(){long received=0;public void check()throws InterruptedIOException{if(received>70000)throw new InterruptedIOException();}public void connection(HttpURLConnection c){}public void progress(long d,long t){received=d;}});}catch(InterruptedIOException e){stopped=true;}require(stopped&&cancelled.length()<bytes.length,"cancel transfer early");cancelled.delete();tests++;
  }finally{server.stop(0);}
  System.out.println("Passed "+tests+" URL and transfer checks");
 }
}
