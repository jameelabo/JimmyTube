import pathlib, urllib.request, zipfile
tools=pathlib.Path(__file__).resolve().parent
for artifact,target in [('desugar_jdk_libs','desugar_jdk_libs.jar'),('desugar_jdk_libs_configuration','desugar_config.jar')]:
    dest=tools/target
    if not dest.exists(): urllib.request.urlretrieve(f'https://dl.google.com/dl/android/maven2/com/android/tools/{artifact}/2.1.5/{artifact}-2.1.5.jar',dest)
with zipfile.ZipFile(tools/'desugar_config.jar') as archive:
    (tools/'desugar.json').write_bytes(archive.read('META-INF/desugar/d8/desugar.json'))
print('Desugaring build tools 2.1.5 ready')
