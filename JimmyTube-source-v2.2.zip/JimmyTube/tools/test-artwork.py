import pathlib,sys,subprocess,hashlib,json
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools/test-python'))
import imageio_ffmpeg
ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
java=next((pathlib.Path.home()/'.cache/neon-nes-android/jdk').glob('*/bin/java.exe'))
javac=java.with_name('javac.exe');probe=root/'build/probe';probe.mkdir(parents=True,exist_ok=True)
subprocess.run([str(javac),'-encoding','UTF-8','-d',str(probe),str(root/'app/java/com/jimmy/tube/ArtworkTags.java'),str(root/'tools/ArtworkProbe.java')],check=True)
cover=probe/'cover-fixture.jpg'
subprocess.run([ffmpeg,'-v','error','-y','-f','lavfi','-i','color=c=coral:s=320x180','-frames:v','1',str(cover)],check=True)
def run(*args):return subprocess.check_output([ffmpeg,'-v','error',*map(str,args)])
def digest(file,map):return run('-i',file,'-map',map,'-c','copy','-f','hash','-hash','sha256','-').strip()
def embed(kind,source,target,cancel=False):
    command=[str(java),'-cp',str(probe),'ArtworkProbe',kind,str(source),str(cover),str(target)]
    if cancel:command.append('cancel')
    subprocess.run(command,check=True)
results=[]
for name,kind,source,image_stream in [
    ('mp3','mp3',probe/'youtube-excerpt.mp3','0:v:0'),
    ('mp4-original','mp4',probe/'download.mp4','0:v:1')]:
    target=probe/(name+'-covered.'+kind);embed(kind,source,target)
    extracted=probe/(name+'-extracted.jpg');run('-y','-i',target,'-map',image_stream,'-frames:v','1','-c:v','copy',extracted)
    assert extracted.read_bytes()==cover.read_bytes(), 'cover bytes changed'
    assert digest(source,'0:a:0')==digest(target,'0:a:0'), 'audio packets changed'
    if kind=='mp4':assert digest(source,'0:v:0')==digest(target,'0:v:0'), 'video packets changed'
    metadata=run('-i',target,'-f','ffmetadata','-').decode('utf-8')
    assert 'جميل 🎵 — عنوان الفيديو' in metadata and 'قناة تجريبية' in metadata
    results.append(dict(test=name,exact_cover=True,media_packets_unchanged=True,unicode_metadata=True))
    again=probe/(name+'-replaced.'+kind);embed(kind,target,again);assert digest(source,'0:a:0')==digest(again,'0:a:0')
    run('-v','error','-i',again,'-map',image_stream,'-frames:v','1','-f','null','-');results.append(dict(test=name+'-retag',valid=True))
for fast in [False,True]:
    name='mp4-'+('faststart' if fast else 'tail-moov');source=probe/(name+'.mp4')
    options=['-y','-i',probe/'download.mp4','-t','2','-map','0:v:0','-map','0:a:0','-c','copy']
    if fast:options+=['-movflags','+faststart']
    run(*options,source);target=probe/(name+'-covered.mp4');embed('mp4',source,target)
    assert digest(source,'0:v:0')==digest(target,'0:v:0') and digest(source,'0:a:0')==digest(target,'0:a:0')
    extracted=probe/(name+'-cover.jpg');run('-y','-i',target,'-map','0:v:1','-frames:v','1','-c:v','copy',extracted);assert extracted.read_bytes()==cover.read_bytes()
    results.append(dict(test=name,exact_cover=True,media_packets_unchanged=True))
original=probe/'download.mp4';before=hashlib.sha256(original.read_bytes()).digest();embed('mp4',original,probe/'cancelled-artwork.mp4',True);assert hashlib.sha256(original.read_bytes()).digest()==before
results.append(dict(test='cancel-with-source-intact',valid=True))
(probe/'artwork-test-results.json').write_text(json.dumps(results,indent=2))
print('Passed',len(results),'artwork checks')
