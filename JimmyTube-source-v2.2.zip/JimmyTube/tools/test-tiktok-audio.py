from pathlib import Path
import sys,subprocess,re
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools/test-python'))
import imageio_ffmpeg
ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
probe=root/'build/probe';video=probe/'tiktok.mp4';pcm=probe/'tiktok.pcm';mp3=probe/'tiktok.mp3'
metadata=subprocess.run([ffmpeg,'-hide_banner','-i',str(video)],capture_output=True,text=True).stderr
for line in metadata.splitlines():
 if 'Duration:' in line or 'Stream #' in line: print(line.strip())
assert 'Video: h264' in metadata and 'Audio: aac' in metadata,metadata
subprocess.run([ffmpeg,'-v','error','-y','-i',str(video),'-map','0:a:0','-ar','48000','-ac','2','-f','s16le',str(pcm)],check=True)
java=next((Path.home()/'.cache/neon-nes-android/jdk').glob('*/bin/java.exe'))
subprocess.run([str(java),'-cp',str(probe)+';'+str(root/'deps/*'),'Mp3Probe',str(pcm),str(mp3),'48000','2'],check=True)
decoded=subprocess.check_output([ffmpeg,'-v','error','-i',str(mp3),'-f','s16le','-ar','48000','-ac','2','-'])
original=pcm.stat().st_size/(48000*2*2);converted=len(decoded)/(48000*2*2)
assert abs(original-converted)<0.1,(original,converted)
assert 10<=original<11,original  # TikTok reports duration rounded to whole seconds.
print('Complete TikTok audio -> MP3: duration',round(converted,3),'seconds;',mp3.stat().st_size,'bytes')
