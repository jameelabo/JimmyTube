import pathlib,sys,subprocess,struct,math,json
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools/test-python'))
import imageio_ffmpeg
ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
java=next((pathlib.Path.home()/'.cache/neon-nes-android/jdk').glob('*/bin/java.exe'))
probe=root/'build/probe'
cp=str(root/'deps/*')+';'+str(probe)
results=[]
for rate,channels,floats in [(48000,2,False),(44100,1,False),(32000,2,False),(48000,2,True)]:
    name=f'{rate}-{channels}-'+('float' if floats else 's16')
    pcm=probe/(name+'.pcm');mp3=probe/(name+'.mp3')
    data=bytearray()
    for frame in range(rate*3):
        for channel in range(channels):
            value=0.5*math.sin(2*math.pi*(440 if channel==0 else 660)*frame/rate)
            data.extend(struct.pack('<f' if floats else '<h',value if floats else int(value*32767)))
    pcm.write_bytes(data)
    command=[str(java),'-cp',cp,'Mp3Probe',str(pcm),str(mp3),str(rate),str(channels)]
    if floats:command.append('float')
    subprocess.run(command,check=True)
    header=mp3.read_bytes()[:4]
    assert header[0]==255 and header[1]&0xe0==0xe0
    assert header[1]>>3&3==3, 'MPEG1'
    assert header[2]>>4==11, '192 kbps'
    assert (header[2]>>2&3)=={44100:0,48000:1,32000:2}[rate]
    assert (header[3]>>6==3)==(channels==1)
    decoded=subprocess.check_output([ffmpeg,'-v','error','-i',str(mp3),'-f','s16le','-acodec','pcm_s16le','-'])
    seconds=len(decoded)/(rate*channels*2)
    assert abs(seconds-3)<0.1,(name,seconds)
    samples=struct.unpack('<'+'h'*(len(decoded)//2),decoded)
    for channel in range(channels):
        segment=samples[int(rate*0.3)*channels+channel:int(rate*1.3)*channels:channels]
        rms=math.sqrt(sum(v*v for v in segment)/len(segment));assert rms>5000,(name,rms)
        frequency=sum(segment[n-1]<=0<segment[n] for n in range(1,len(segment)))
        assert abs(frequency-(440 if channel==0 else 660))<4,(name,frequency)
    results.append(dict(test=name,duration=seconds,bytes=mp3.stat().st_size,valid=True))
source=probe/'download.m4a'
if source.exists():
    pcm=probe/'youtube-excerpt.pcm';mp3=probe/'youtube-excerpt.mp3'
    subprocess.run([ffmpeg,'-v','error','-y','-i',str(source),'-t','6','-ar','48000','-ac','2','-f','s16le',str(pcm)],check=True)
    subprocess.run([str(java),'-cp',cp,'Mp3Probe',str(pcm),str(mp3),'48000','2'],check=True)
    decoded=subprocess.check_output([ffmpeg,'-v','error','-i',str(mp3),'-f','s16le','-acodec','pcm_s16le','-'])
    seconds=len(decoded)/(48000*2*2);assert abs(seconds-6)<0.1
    results.append(dict(test='real-youtube-audio-excerpt',duration=seconds,bytes=mp3.stat().st_size,valid=True))
(probe/'mp3-test-results.json').write_text(json.dumps(results,indent=2))
print('Passed',len(results),'MP3 encode/decode checks')
