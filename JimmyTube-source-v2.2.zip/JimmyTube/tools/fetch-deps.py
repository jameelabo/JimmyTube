import pathlib, urllib.request, zipfile, hashlib, json
root = pathlib.Path(__file__).resolve().parents[1]
deps = root / 'deps'
deps.mkdir(exist_ok=True)
items = [
 ('https://jitpack.io/com/github/TeamNewPipe/NewPipeExtractor/v0.26.5/NewPipeExtractor-v0.26.5.jar', 'extractor.jar'),
 ('https://jitpack.io/com/github/TeamNewPipe/nanojson/e9d656ddb49a412a5a0a5d5ef20ca7ef09549996/nanojson-e9d656ddb49a412a5a0a5d5ef20ca7ef09549996.jar', 'nanojson.jar'),
 ('https://repo.maven.apache.org/maven2/org/jsoup/jsoup/1.22.2/jsoup-1.22.2.jar', 'jsoup.jar'),
 ('https://repo.maven.apache.org/maven2/com/google/code/findbugs/jsr305/3.0.2/jsr305-3.0.2.jar', 'jsr305.jar'),
 ('https://repo.maven.apache.org/maven2/com/google/protobuf/protobuf-javalite/4.35.1/protobuf-javalite-4.35.1.jar', 'protobuf.jar'),
 ('https://repo.maven.apache.org/maven2/org/mozilla/rhino/1.8.1/rhino-1.8.1.jar', 'rhino.jar'),
 ('https://repo.maven.apache.org/maven2/org/mozilla/rhino-engine/1.8.1/rhino-engine-1.8.1.jar', 'rhino-engine.jar'),
 ('https://repo.maven.apache.org/maven2/io/vacco/jlame/jlame/3.100.2/jlame-3.100.2.jar', 'jlame.jar')]
manifest=[]
for url, name in items:
    target=deps/name
    if not target.exists(): urllib.request.urlretrieve(url,target)
    # Strip multi-release Java 9+ classes, Android uses the base implementation.
    with zipfile.ZipFile(target) as z:
        entries={i.filename:z.read(i) for i in z.infolist() if not i.filename.startswith('META-INF/versions/') and i.filename!='module-info.class' and not (name=='jlame.jar' and (i.filename.startswith('io/vacco/jlame/spi/') or i.filename.startswith('META-INF/services/')))}
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for k,v in entries.items(): z.writestr(k,v)
    manifest.append(dict(name=name,url=url,sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
    print(name,target.stat().st_size)
(deps/'manifest.json').write_text(json.dumps(manifest,indent=2))
