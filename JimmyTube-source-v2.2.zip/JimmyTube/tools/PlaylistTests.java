import com.jimmy.tube.*;
import org.schabi.newpipe.extractor.*;
import org.schabi.newpipe.extractor.playlist.PlaylistInfo;
import org.schabi.newpipe.extractor.stream.*;
import java.util.*;

public class PlaylistTests {
 static int tests;
 static void ok(boolean b,String label){if(!b)throw new AssertionError(label);tests++;}
 static TubeEngine.Choice video(int h){return new TubeEngine.Choice("فيديو MP4 · "+h+"p","video",null,"mp4","video/mp4");}
 public static void main(String[] args)throws Exception{
  String id="PL8dPuuaLjXtOAKed_MxxWBNaPno5h3Zs8",url="https://www.youtube.com/playlist?list="+id;
  for(String s:new String[]{url,"https://m.youtube.com/watch?v=aqz-KE-bpKQ&list="+id,"https://youtu.be/aqz-KE-bpKQ?list="+id,"شاهد "+url+"&index=2"})ok(url.equals(PlaylistSupport.canonical(s)),"playlist URL");
  for(String s:new String[]{"https://youtube.com.evil.com/playlist?list="+id,"https://youtube.com@evil.com/playlist?list="+id,"https://example.com/playlist?list="+id,"https://youtu.be/aqz-KE-bpKQ","no URL"})ok(PlaylistSupport.canonical(s)==null,"not playlist");
  for(String s:new String[]{"WL","LL","bad!","RDaqz-KE-bpKQ"}){boolean rejected=false;try{PlaylistSupport.canonical("https://youtube.com/playlist?list="+s);}catch(IllegalArgumentException e){rejected=true;}ok(rejected,"invalid/private/mix");}
  TubeEngine.Choice mp3=new TubeEngine.Choice("MP3",null,"original","mp3","audio/mpeg");
  List<TubeEngine.Choice> options=Arrays.asList(video(1080),video(360),mp3,video(720));
  ok(PlaylistSupport.choose(options,"mp3",0)==mp3,"MP3 exact original choice");
  ok(PlaylistSupport.choose(options,"mp4",720)==options.get(3),"720 exact");
  ok(PlaylistSupport.choose(options,"mp4",480)==options.get(1),"lower fallback");
  ok(PlaylistSupport.choose(options,"mp4",240)==options.get(1),"lowest fallback");
  ok(PlaylistSupport.choose(options,"mp4",2160)==options.get(0),"highest");
  ok(PlaylistSupport.choose(Arrays.asList(video(720)),"mp3",0)==null,"missing audio");
  ok(PlaylistSupport.choose(Arrays.asList(mp3),"mp4",720)==null,"missing video");
  ArrayList<PlaylistSupport.Item> items=new ArrayList<>();
  StreamInfoItem a=new StreamInfoItem(0,"https://youtu.be/aqz-KE-bpKQ","A",StreamType.VIDEO_STREAM);
  StreamInfoItem duplicate=new StreamInfoItem(0,"https://youtube.com/watch?v=aqz-KE-bpKQ","A",StreamType.VIDEO_STREAM);
  StreamInfoItem live=new StreamInfoItem(0,"https://youtu.be/Kn56bMZ9OE8","Live",StreamType.LIVE_STREAM);
  StreamInfoItem b=new StreamInfoItem(0,"https://youtu.be/Kn56bMZ9OE8","B",StreamType.VIDEO_STREAM);
  ok(PlaylistSupport.append(items,Arrays.asList(a,duplicate,live))==2&&items.size()==1,"dedupe / skip live");items.get(0).selected=false;
  ok(PlaylistSupport.append(items,Arrays.asList(a,b))==1&&items.size()==2&&!items.get(0).selected&&items.get(1).selected,"pagination preserves selection and order");
  for(int n=items.size();n<PlaylistSupport.LIMIT;n++)items.add(new PlaylistSupport.Item("placeholder"+n,"X"));PlaylistSupport.append(items,Arrays.asList(b));ok(items.size()==PlaylistSupport.LIMIT,"bounded list");
  System.out.println("Playlist tests passed: "+tests);
  if(args.length>0){
   TubeEngine.init();url="https://www.youtube.com/playlist?list=PLMC9KNkIncKtPzgY-5rmhvj7fax8fdxoj";PlaylistInfo info=PlaylistInfo.getInfo(url);ArrayList<PlaylistSupport.Item> real=new ArrayList<>();PlaylistSupport.append(real,info.getRelatedItems());int first=real.size();
   System.out.println("LIVE name="+info.getName()+" count="+info.getStreamCount()+" first="+first+" next="+info.hasNextPage());
   ok(first>0,"actual first page");ok(info.hasNextPage(),"actual continuation");
   ListExtractor.InfoItemsPage<StreamInfoItem> page=PlaylistInfo.getMoreItems(ServiceList.YouTube,url,info.getNextPage());PlaylistSupport.append(real,page.getItems());ok(real.size()>first,"actual second page");
   StreamInfo stream=StreamInfo.getInfo(real.get(0).url);List<TubeEngine.Choice> choices=TubeEngine.choices(stream);ok(PlaylistSupport.choose(choices,"mp3",0)!=null,"actual MP3 choice");ok(PlaylistSupport.choose(choices,"mp4",720)!=null,"actual MP4 choice");
   System.out.println("LIVE total loaded="+real.size()+" first media="+stream.getName()+" tests="+tests);
  }
 }
}
