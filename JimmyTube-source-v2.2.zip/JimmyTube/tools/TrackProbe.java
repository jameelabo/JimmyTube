import com.jimmy.tube.TubeEngine;
import org.schabi.newpipe.extractor.stream.*;
import java.net.*;
public class TrackProbe {
 public static void main(String[] args)throws Exception{
  TubeEngine.init();StreamInfo info=StreamInfo.getInfo(TubeEngine.canonical(args[0]));
  System.out.println("Video: "+info.getName());
  for(AudioStream a:info.getAudioStreams())System.out.println("Track "+a.getAudioTrackId()+" type="+a.getAudioTrackType()+" name="+a.getAudioTrackName()+" format="+a.getFormat()+" bitrate="+a.getAverageBitrate());
  AudioStream best=TubeEngine.originalAudio(info.getAudioStreams());if(best==null)throw new Exception("No unambiguous original M4A");
  System.out.println("SELECTED: "+best.getAudioTrackId()+" type="+best.getAudioTrackType()+" name="+best.getAudioTrackName());
  for(TubeEngine.Choice c:TubeEngine.choices(info))System.out.println("Choice: "+c.label+" mux="+c.needsMux()+" selectedAudio="+(best.getContent().equals(c.audio)));
  HttpURLConnection c=(HttpURLConnection)new URL(best.getContent()).openConnection();c.setRequestProperty("Range","bytes=0-1023");c.setRequestProperty("User-Agent",TubeEngine.UA);c.setConnectTimeout(20000);c.setReadTimeout(20000);try{if(c.getResponseCode()>=400)throw new Exception("Media HTTP "+c.getResponseCode());try(java.io.InputStream in=c.getInputStream()){System.out.println("Audio response "+c.getResponseCode()+", read "+in.read(new byte[1024])+" bytes");}}finally{c.disconnect();}
 }
}
