import com.jimmy.tube.*;
import java.net.*;
import java.io.*;

public class TikTokLiveProbe {
 public static void main(String[] args)throws Exception{
  for(String url:args)try{
   MediaInfo info=TikTokEngine.inspect(url);TubeEngine.Choice choice=info.choices.get(0);
   File file=new File("JimmyTube/build/probe/tiktok.mp4");
   MediaTransfer.download(choice.video,file,new MediaTransfer.Monitor(){public void check(){}public void connection(HttpURLConnection c){}public void progress(long done,long total){}},choice.referer,choice.cookie);
   System.out.println("OK "+url+" duration="+info.getDuration()+" bytes="+file.length());return;
  }catch(Exception e){System.out.println("FAILED "+url+" "+e.getClass().getSimpleName()+": "+e.getMessage());}
  throw new IOException("No working public example on this connection");
 }
}
