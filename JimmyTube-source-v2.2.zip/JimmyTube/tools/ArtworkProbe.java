import com.jimmy.tube.ArtworkTags;
import java.io.*;
import java.nio.file.*;
public class ArtworkProbe {
 public static void main(String[] args)throws Exception{
  final int[] calls={0};boolean cancel=args.length>4&&args[4].equals("cancel");
  ArtworkTags.Monitor monitor=()->{if(cancel&&++calls[0]>3)throw new InterruptedIOException("test cancellation");};
  byte[] jpg=Files.readAllBytes(Paths.get(args[2]));
  try{if(args[0].equals("mp3"))ArtworkTags.mp3(new File(args[1]),new File(args[3]),jpg,"جميل 🎵 — عنوان الفيديو","قناة تجريبية",monitor);else ArtworkTags.mp4(new File(args[1]),new File(args[3]),jpg,"جميل 🎵 — عنوان الفيديو","قناة تجريبية",monitor);if(cancel)throw new AssertionError("Cancellation was ignored");System.out.println("Artwork embedded in "+args[0]);}
  catch(InterruptedIOException e){if(!cancel)throw e;System.out.println("Cancellation honored");}
 }
}
