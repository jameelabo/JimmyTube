import pathlib,zipfile,json,hashlib
root=pathlib.Path(__file__).resolve().parents[1]
target=root/'dist/JimmyTube-source-v2.2.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
    for name in ['README.md','LICENSE','build.ps1','.gitignore']:
        archive.write(root/name,'JimmyTube/'+name)
    for folder in ['app','deps']:
        for p in (root/folder).rglob('*'):
            if p.is_file(): archive.write(p,'JimmyTube/'+p.relative_to(root).as_posix())
    for name in ['fetch-deps.py','fetch-build-tools.py','package-source.py','Probe.java','EngineTests.java','Mp3Probe.java','test-mp3.py','ArtworkProbe.java','test-artwork.py','AudioTrackTests.java','TrackProbe.java','PlaylistTests.java','TikTokTests.java','LanguageTests.java','TikTokLiveProbe.java','test-tiktok-audio.py','jlame-sources.jar','desugar.json','desugar_jdk_libs.jar','desugar_config.jar']:
        archive.write(root/'tools'/name,'JimmyTube/tools/'+name)
with zipfile.ZipFile(root/'dist/JimmyTube-v2.2.apk') as z:
    names=z.namelist()
    assert 'classes.dex' in names and 'classes2.dex' in names
    assert 'org/mozilla/javascript/resources/Messages.properties' in names
    assert 'assets/licenses/Apache-2.0.txt' in names
    assert 'assets/licenses/JLAME-LGPL.txt' in names
    assert not any('\\' in n for n in names)
    assert not any(n.endswith('.jks') or n.endswith('signing.json') for n in names)
with zipfile.ZipFile(target) as z:
    assert not any(n.endswith('.jks') or n.endswith('signing.json') for n in z.namelist())
for p in [root/'dist/JimmyTube-v2.2.apk',target]:
    print(p.name,p.stat().st_size,'bytes',hashlib.sha256(p.read_bytes()).hexdigest())




