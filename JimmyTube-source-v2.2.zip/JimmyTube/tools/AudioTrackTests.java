import com.jimmy.tube.TubeEngine;
import org.schabi.newpipe.extractor.*;
import org.schabi.newpipe.extractor.stream.*;
import org.schabi.newpipe.extractor.services.youtube.ItagItem;
import java.util.*;
public class AudioTrackTests {
 static int checks=0;
 static void check(boolean value,String name){if(!value)throw new AssertionError(name);checks++;}
 static AudioStream audio(String id,AudioTrackType type,int rate){return new AudioStream.Builder().setId(id+rate).setContent("https://example.com/"+id+rate,true).setMediaFormat(MediaFormat.M4A).setAverageBitrate(rate).setAudioTrackId(id).setAudioTrackType(type).build();}
 static VideoStream video(boolean silent)throws Exception{ItagItem itag=new ItagItem(silent?136:22,ItagItem.ItagType.VIDEO,MediaFormat.MPEG_4,"720p");itag.setHeight(720);itag.setWidth(1280);itag.setCodec("avc1.4d401f");return new VideoStream.Builder().setId(silent?"silent":"combined").setContent("https://example.com/"+(silent?"silent":"combined-dub"),true).setMediaFormat(MediaFormat.MPEG_4).setResolution("720p").setIsVideoOnly(silent).setItagItem(itag).build();}
 public static void main(String[] args)throws Exception{
  AudioStream original=audio("en.0",AudioTrackType.ORIGINAL,128),dub=audio("ar.1",AudioTrackType.DUBBED,256),description=audio("en.2",AudioTrackType.DESCRIPTIVE,384);
  check(TubeEngine.originalAudio(Arrays.asList(dub,original,description))==original,"original wins over higher bitrate dub");
  check(TubeEngine.originalAudio(Arrays.asList(original,dub))==original,"independent of order");
  AudioStream arabic=audio("ar.0",AudioTrackType.ORIGINAL,128);check(TubeEngine.originalAudio(Arrays.asList(arabic,audio("en.1",AudioTrackType.DUBBED,256)))==arabic,"Arabic original remains Arabic");
  AudioStream better=audio("en.0",AudioTrackType.ORIGINAL,192);check(TubeEngine.originalAudio(Arrays.asList(original,better,dub))==better,"bitrate within original track");
  check(TubeEngine.originalAudio(Arrays.asList(dub,description))==null,"never fallback to known dub or description");
  AudioStream legacy=audio(null,null,128);check(TubeEngine.originalAudio(Arrays.asList(legacy))==legacy,"unlabelled single track");
  check(TubeEngine.originalAudio(Arrays.asList(audio("en.0",null,128),audio("ar.1",null,128)))==null,"ambiguous languages rejected");
  check(TubeEngine.originalAudio(Arrays.asList(original,audio("ar.1",null,512)))==original,"unknown other track cannot override original");
  check(TubeEngine.originalAudio(Arrays.asList(original,audio("en.0",null,512)))==original,"explicit original beats untyped matching track");
  StreamInfo info=new StreamInfo(0,"https://youtube.com/watch?v=aqz-KE-bpKQ","id",StreamType.VIDEO_STREAM,"title","uploader",0);info.setAudioStreams(Arrays.asList(dub,original));info.setVideoStreams(Arrays.asList(video(false)));info.setVideoOnlyStreams(Arrays.asList(video(true)));
  List<TubeEngine.Choice> choices=TubeEngine.choices(info);check(choices.size()==2,"video plus MP3");
  for(TubeEngine.Choice choice:choices){check(original.getContent().equals(choice.audio),"both modes use original");if(choice.video!=null)check(choice.needsMux()&&choice.video.endsWith("silent"),"avoid localized combined video");}
  info.setAudioStreams(Arrays.asList(dub));check(TubeEngine.choices(info).isEmpty(),"no unsafe combined fallback when original absent");
  info.setAudioStreams(Arrays.asList(legacy));check(TubeEngine.choices(info).get(0).video.endsWith("combined-dub"),"legacy combined stream remains supported");
  System.out.println("Passed "+checks+" original audio selection checks");
 }
}
