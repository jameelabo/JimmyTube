import com.jimmy.tube.*;
import java.io.*;
import java.util.*;
import java.nio.file.*;
import java.net.*;

public class TikTokTests {
 static int count;
 static void ok(boolean b,String reason){if(!b)throw new AssertionError(reason);count++;}
 static void reject(String input){boolean failed=false;try{TikTokEngine.canonical(input);}catch(Exception e){failed=true;}ok(failed,"reject "+input);}
 static final String URL="https://www.tiktok.com/@scout2015/video/6718335390845095173";
 static String item(String source){return "{\"id\":\"6718335390845095173\",\"desc\":\"Test title\",\"author\":{\"nickname\":\"Creator\"},\"video\":{\"width\":576,\"height\":1024,\"duration\":10,\"playAddr\":"+source+",\"cover\":\"https://p16.tiktokcdn.com/cover.jpeg\"},\"music\":{\"playUrl\":\"https://music.tiktokcdn.com/wrong-track.mp3\"}}";}
 static String script(String id,String json){return "<html><script type='application/json' id='"+id+"'>"+json+"</script></html>";}
 static void badPage(String html){boolean failed=false;try{TikTokEngine.parse(html,URL);}catch(Exception e){failed=true;}ok(failed,"reject unusable page");}
 public static void main(String[] args)throws Exception{
  for(String s:new String[]{URL,URL+"?is_from_webapp=1","شاهد "+URL,"http://m.tiktok.com/@scout2015/video/6718335390845095173/"})ok(URL.equals(TikTokEngine.canonical(s)),"canonical URL");
  for(String s:new String[]{"https://vt.tiktok.com/ZS123abcd/","https://vm.tiktok.com/ZM123abcd/","https://www.tiktok.com/t/ZTRC5abcd/"})ok(TikTokEngine.canonical(s).equals(s),"share URL");
  for(String s:new String[]{"https://tiktok.com.evil.com/@scout2015/video/6718335390845095173","https://www.tiktok.com@evil.com/@scout2015/video/6718335390845095173","https://www.tiktok.com:444/@scout2015/video/6718335390845095173","https://www.tiktok.com/@scout2015","https://www.tiktok.com/@scout2015/live","https://www.tiktok.com/@scout2015/photo/6718335390845095173","https://vm.tiktok.com/../login","no URL"})reject(s);
  ok(!TikTokEngine.isLink("https://youtube.com/watch?v=aqz-KE-bpKQ"),"YouTube routing");ok(TikTokEngine.isLink("شاهد "+URL),"TikTok routing");
  String source="https://v16-webapp-prime.tiktok.com/video/source.mp4";
  String record=item("\""+source+"\"");
  for(String html:new String[]{script("api-data","{\"videoDetail\":{\"statusCode\":0,\"itemInfo\":{\"itemStruct\":"+record+"}}}"),script("__UNIVERSAL_DATA_FOR_REHYDRATION__","{\"__DEFAULT_SCOPE__\":{\"webapp.video-detail\":{\"itemInfo\":{\"itemStruct\":"+record+"}}}}"),script("SIGI_STATE","{\"ItemModule\":{\"6718335390845095173\":"+record+"}}")}){
   MediaInfo info=TikTokEngine.parse(html,URL);ok(info.getName().equals("Test title")&&info.getUploaderName().equals("Creator")&&info.getDuration()==10,"metadata");
   ok(info.choices.size()==2&&source.equals(info.choices.get(0).video)&&source.equals(info.choices.get(1).audio),"MP3 uses complete video instead of music");ok(URL.equals(info.choices.get(1).referer)&&info.getThumbnails().size()==1,"referer and cover");
  }
  MediaInfo structured=TikTokEngine.parse(script("SIGI_STATE","{\"ItemModule\":{\"6718335390845095173\":"+item("[{\"src\":\""+source+"\"}]")+"}}"),URL);ok(source.equals(structured.choices.get(0).video),"structured play URL");
  badPage(script("api-data","{\"videoDetail\":{\"statusCode\":10222}}"));badPage("<html>Please wait, verify</html>");badPage(script("SIGI_STATE",record.replace("6718335390845095173","6718335390845095174")));
  badPage(script("SIGI_STATE",item("\"https://evil.com/video.mp4\"")));badPage(script("SIGI_STATE",item("\"https://tiktokcdn.com.evil.com/video.mp4\"")));badPage(script("SIGI_STATE",record.replace("\"duration\":10","\"duration\":0")));
  badPage(script("SIGI_STATE",item("\"https://v16.tiktok.com/media-video-hvc1/\"")));
  ok(TubeEngine.sourceUrl(URL).equals(URL)&&TubeEngine.sourceUrl("https://youtu.be/aqz-KE-bpKQ").equals("https://www.youtube.com/watch?v=aqz-KE-bpKQ"),"shared router");
  System.out.println("TikTok checks passed: "+count);
  if(args.length>0){
   MediaInfo info=TikTokEngine.inspect(URL);System.out.println("LIVE duration="+info.getDuration()+" options="+info.choices.size()+" title="+info.getName());
   File output=new File("JimmyTube/build/probe/tiktok.mp4");TubeEngine.Choice choice=info.choices.get(0);
   MediaTransfer.download(choice.video,output,new MediaTransfer.Monitor(){public void check(){}public void connection(HttpURLConnection c){}public void progress(long done,long total){}},choice.referer,choice.cookie);
   try(RandomAccessFile file=new RandomAccessFile(output,"r")){file.seek(4);ok(file.readInt()==0x66747970,"actual MP4 header");}
   ok(output.length()>10000,"actual complete media");TubeEngine.init();MediaInfo youtube=TubeEngine.inspect("https://youtu.be/aqz-KE-bpKQ");ok(!youtube.choices.isEmpty()&&youtube.getUrl().contains("aqz-KE-bpKQ"),"actual YouTube shared inspector");System.out.println("LIVE downloaded="+output.length()+" checks="+count);
  }
 }
}
