import com.jimmy.tube.TubeEngine;
import com.jimmy.tube.MediaTransfer;
import org.schabi.newpipe.extractor.stream.*;
import java.net.*;
public class Probe {
 public static void main(String[] args)throws Exception {
  TubeEngine.init();
  String url=TubeEngine.canonical(args.length>0?args[0]:"https://www.youtube.com/watch?v=aqz-KE-bpKQ");
  StreamInfo info=StreamInfo.getInfo(url);
  System.out.println("Title: "+info.getName()+"; duration="+info.getDuration());
  System.out.println("video="+info.getVideoStreams().size()+" videoOnly="+info.getVideoOnlyStreams().size()+" audio="+info.getAudioStreams().size());
  for(TubeEngine.Choice choice:TubeEngine.choices(info)) System.out.println(choice.label+" mux="+choice.needsMux());
  for(TubeEngine.Choice choice:TubeEngine.choices(info)) {
   System.out.println(choice.label+" mux="+choice.needsMux());
   HttpURLConnection c=(HttpURLConnection)new URL(choice.video!=null?choice.video:choice.audio).openConnection();
   c.setRequestProperty("User-Agent",TubeEngine.UA);c.setRequestProperty("Range","bytes=0-1023");c.setConnectTimeout(20000);c.setReadTimeout(20000);
   try {System.out.println("Media HTTP "+c.getResponseCode()+" type="+c.getContentType()); if(c.getResponseCode()>=400)throw new Exception("Media rejected");try(java.io.InputStream in=c.getInputStream()){System.out.println("Read "+in.read(new byte[1024])+" bytes");}}
   finally{c.disconnect();}
   break;
  }
  if(TubeEngine.choices(info).isEmpty())throw new Exception("No supported formats");
  if(args.length>1&&args[1].equals("full")) {
   TubeEngine.Choice video=null,audio=null;
   for(TubeEngine.Choice c:TubeEngine.choices(info)) {if(c.video!=null&&!c.needsMux())video=c;if(c.video==null)audio=c;}
   if(video==null)throw new Exception("No muxed MP4 for probe");
   for(TubeEngine.Choice c:new TubeEngine.Choice[]{video,audio})if(c!=null){
    java.io.File target=new java.io.File("JimmyTube/build/probe/download."+(c.extension.equals("mp3")?"m4a":c.extension));
    MediaTransfer.download(c.video!=null?c.video:c.audio,target,new MediaTransfer.Monitor(){
     public void check(){} public void connection(HttpURLConnection connection){} public void progress(long done,long total){}
    });
    System.out.println("Downloaded source media for "+c.label+": "+target.length()+" bytes (MP3 conversion is tested separately)");
    try(java.io.RandomAccessFile f=new java.io.RandomAccessFile(target,"r")){byte[] header=new byte[12];f.readFully(header);if(!new String(header,4,4,java.nio.charset.StandardCharsets.US_ASCII).equals("ftyp"))throw new Exception("Invalid MP4/M4A header");}
   }
  }
 }
}
