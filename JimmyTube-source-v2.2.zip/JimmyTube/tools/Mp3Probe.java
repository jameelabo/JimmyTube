import com.jimmy.tube.Mp3Sink;
import java.io.*;
import java.nio.*;

public class Mp3Probe {
 public static void main(String[] args)throws Exception {
  int rate=Integer.parseInt(args[2]),channels=Integer.parseInt(args[3]);boolean floats=args.length>4&&args[4].equals("float");
  long frames;
  try(InputStream in=new BufferedInputStream(new FileInputStream(args[0]));OutputStream out=new BufferedOutputStream(new FileOutputStream(args[1]));Mp3Sink sink=new Mp3Sink(out,rate,channels)){
   byte[] b=new byte[4096*channels*(floats?4:2)];int fill=0,count;
   while((count=in.read(b,fill,b.length-fill))!=-1){fill+=count;if(fill==b.length){sink.write(ByteBuffer.wrap(b),floats);fill=0;}}
   if(fill>0)sink.write(ByteBuffer.wrap(b,0,fill),floats);sink.finish();frames=sink.frames();
  }
  if(frames==0)throw new Exception("No PCM frames");
  try(RandomAccessFile mp3=new RandomAccessFile(args[1],"r")){int a=mp3.readUnsignedByte(),b=mp3.readUnsignedByte();if(a!=255||(b&224)!=224)throw new Exception("Missing MP3 frame sync");}
  System.out.println("Encoded "+frames+" frames, "+rate+" Hz, "+channels+" channels, "+new File(args[1]).length()+" bytes");
 }
}
